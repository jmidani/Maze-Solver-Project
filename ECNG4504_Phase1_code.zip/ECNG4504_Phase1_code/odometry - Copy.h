// =====================================================================
//  odometry.h  -  Pose estimate without encoders
//
//  Position: integrates the average commanded wheel PWM over time along the
//            current heading (edges are straight, heading is exact).
//  Heading:  discrete N/E/S/W, updated by the navigation layer on every
//            90/180-degree turn.
//  Rotation: integrates (L-R)/2 PWM over time. Only used to work out which
//            line a tank-turn recovery ended on. Self-calibrates on clean turns.
// =====================================================================
#pragma once
#include <stdint.h>

struct Pose {
  int32_t x, y;        // odometry units (see ODO_SCALE / ODO_UNITS_PER_CM)
  uint8_t heading;     // 0=N 1=E 2=S 3=W
};

extern Pose gPose;

void    odoReset(int32_t x, int32_t y, uint8_t heading);
void    odoUpdate(bool countRotation);   // call every loop while moving
void    odoShift(int32_t dx, int32_t dy); // apply a correction (node snap)
int32_t odoDistance();                    // total along-track distance (units)

void    odoBeginManeuver();              // zero the rotation accumulator
int32_t odoManeuverRot();                // PWM*ms, + = "L" direction
void    odoCalibrateTurn(int32_t rot, uint8_t quarters);
float   odoRotToQuarters(int32_t rot);   // + = "L" quarter turns
int32_t odoRotPer90();
