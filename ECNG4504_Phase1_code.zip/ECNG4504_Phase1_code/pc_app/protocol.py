"""
protocol.py - Robot <-> PC message protocol (ECNG 4504 Phase 1)

All messages are ASCII lines terminated by '\n'.

PC -> robot commands:
    START_TRAIN  START_SOLVE  STOP  RESET  STATUS_REQUEST
    GET_MAP  GET_PATH  CLEAR_MAP  ODO  PING

Robot -> PC messages:
    ROBOT_READY:<pathValid>,<nodes>,<mission>
    ACK:<command>
    ERROR:<code>[,<detail>]
    TRAINING_STARTED
    TRAINING_COMPLETED:<nodes>,<actions>,<cost>,<partial>
    SOLVING_STARTED
    SOLVING_COMPLETED
    CURRENT_STATUS:<mission>,<nav>,<node>,<heading>,<nodes>,<frontiers>,<step>/<total>,<x>,<y>,<pathValid>
    FINAL_PATH:BEGIN,<nodes>,<actions>,<cost>,<partial>
    FINAL_PATH:A,<action chunk>        (S/L/R/U, one per intermediate node)
    FINAL_PATH:N,<id>,<id>,...         (node ids, start..end)
    FINAL_PATH:END
    MAP:BEGIN,<count>,<start>,<end>,<startHeading>,<unitsPerCm*10>
    MAP:N,<id>,<x>,<y>,<nN>,<nE>,<nS>,<nW>,<flags>   (255 = no exit, 254 = unexplored)
    MAP:END
    EVT:<name>[,<args>]                (NODE_NEW, LOOP_CLOSED, END_FOUND, MISSION, ...)
    NAV:<state>  DIAG:<sensors>,<err*100>,<L>,<R>  ODO:...  PONG  BOOT

This module has no BLE or GUI code, so it can be tested on its own.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional

NO_EXIT = 255
UNEXPLORED = 254
NF_START, NF_END, NF_DEADEND = 1, 2, 4
HEADINGS = "NESW"

COMMANDS = ["START_TRAIN", "START_SOLVE", "STOP", "RESET", "STATUS_REQUEST",
            "GET_MAP", "GET_PATH", "CLEAR_MAP", "ODO", "PING"]


@dataclass
class MapNode:
    id: int
    x: int
    y: int
    nbr: List[int] = field(default_factory=lambda: [NO_EXIT] * 4)
    flags: int = 0
    linked: bool = False      # True once received in a full MAP dump


@dataclass
class RobotModel:
    """Everything the GUI shows, updated by RobotModel.feed(line)."""
    mission: str = "UNKNOWN"
    nav: str = "-"
    node: int = 255
    heading: str = "-"
    nodes: int = 0
    frontiers: int = 0
    step: int = 0
    total: int = 0
    x: int = 0
    y: int = 0
    path_valid: bool = False
    units_per_cm: float = 15.0

    map_nodes: Dict[int, MapNode] = field(default_factory=dict)
    start_node: int = 255
    end_node: int = 255

    path_nodes: List[int] = field(default_factory=list)
    path_actions: str = ""
    path_cost: int = 0
    path_partial: bool = False

    # in-progress dumps
    _map_buf: Dict[int, MapNode] = field(default_factory=dict)
    _map_hdr: Optional[list] = None
    _path_nodes_buf: List[int] = field(default_factory=list)
    _path_act_buf: str = ""
    _path_hdr: Optional[list] = None

    def feed(self, line: str) -> Optional[dict]:
        """Parse one line. Returns an event dict for the GUI, or None."""
        line = line.strip()
        if not line:
            return None
        key, _, rest = line.partition(":")
        args = rest.split(",") if rest else []

        try:
            if key == "CURRENT_STATUS" and len(args) >= 10:
                self.mission, self.nav = args[0], args[1]
                self.node = int(args[2])
                self.heading = args[3]
                self.nodes = int(args[4])
                self.frontiers = int(args[5])
                st, _, tot = args[6].partition("/")
                self.step, self.total = int(st), int(tot or 0)
                self.x, self.y = int(args[7]), int(args[8])
                self.path_valid = args[9] == "1"
                return {"type": "status"}

            if key == "ROBOT_READY":
                if len(args) >= 3:
                    self.path_valid = args[0] == "1"
                    self.nodes = int(args[1])
                    self.mission = args[2]
                return {"type": "ready"}

            if key == "NAV" and args:
                self.nav = args[0]
                return {"type": "nav"}

            if key == "ACK":
                return {"type": "ack", "cmd": rest}

            if key == "ERROR":
                return {"type": "error", "code": args[0] if args else "?",
                        "detail": ",".join(args[1:])}

            if key in ("TRAINING_STARTED", "SOLVING_STARTED"):
                if key == "TRAINING_STARTED":
                    self.map_nodes.clear()
                    self.path_nodes, self.path_actions = [], ""
                    self.start_node = self.end_node = 255
                return {"type": "phase", "name": key}

            if key == "TRAINING_COMPLETED":
                return {"type": "phase", "name": key, "args": args}

            if key == "SOLVING_COMPLETED":
                self.step = self.total
                return {"type": "phase", "name": key}

            if key == "EVT":
                return self._event(args)

            if key == "MAP":
                return self._map(args)

            if key == "FINAL_PATH":
                return self._path(args)

        except (ValueError, IndexError):
            return {"type": "bad", "line": line}

        return {"type": "other", "line": line}

    # ---- helpers ----
    def _event(self, args: List[str]) -> dict:
        name = args[0] if args else ""
        if name == "NODE_NEW" and len(args) >= 6:
            nid, x, y = int(args[1]), int(args[2]), int(args[3])
            flags = int(args[5])
            n = self.map_nodes.get(nid) or MapNode(nid, x, y)
            n.x, n.y, n.flags = x, y, flags
            self.map_nodes[nid] = n
            if flags & NF_END:
                self.end_node = nid
        elif name == "EXP_BEGIN":
            self.map_nodes = {0: MapNode(0, 0, 0, flags=NF_START)}
            self.start_node = 0
        elif name == "MISSION" and len(args) >= 2:
            self.mission = args[1]
        return {"type": "event", "name": name, "args": args[1:]}

    def _map(self, args: List[str]) -> Optional[dict]:
        tag = args[0]
        if tag == "BEGIN":
            self._map_hdr = [int(a) for a in args[1:6]]
            self._map_buf = {}
        elif tag == "N" and len(args) >= 9:
            v = [int(a) for a in args[1:9]]
            self._map_buf[v[0]] = MapNode(v[0], v[1], v[2], v[3:7], v[7], True)
        elif tag == "END" and self._map_hdr is not None:
            count, start, end, _sh, upc10 = self._map_hdr
            self.map_nodes = self._map_buf
            self.start_node, self.end_node = start, end
            if upc10 > 0:
                self.units_per_cm = upc10 / 10.0
            self._map_hdr = None
            complete = len(self.map_nodes) == count
            return {"type": "map", "complete": complete}
        return None

    def _path(self, args: List[str]) -> Optional[dict]:
        tag = args[0]
        if tag == "BEGIN":
            self._path_hdr = [int(a) for a in args[1:5]]
            self._path_nodes_buf, self._path_act_buf = [], ""
        elif tag == "A":
            self._path_act_buf += ",".join(args[1:])
        elif tag == "N":
            self._path_nodes_buf += [int(a) for a in args[1:]]
        elif tag == "END" and self._path_hdr is not None:
            n_nodes, n_act, cost, partial = self._path_hdr
            self.path_nodes = self._path_nodes_buf
            self.path_actions = self._path_act_buf
            self.path_cost = cost
            self.path_partial = partial == 1
            self._path_hdr = None
            ok = len(self.path_nodes) == n_nodes and len(self.path_actions) == n_act
            return {"type": "path", "complete": ok}
        return None


class LineAssembler:
    """HM-10 notifications arrive in <= 20-byte pieces: rebuild whole lines."""

    def __init__(self) -> None:
        self._buf = bytearray()

    def push(self, data: bytes) -> List[str]:
        self._buf += data
        lines = []
        while True:
            i = self._buf.find(b"\n")
            if i < 0:
                break
            raw = bytes(self._buf[:i]).strip(b"\r")
            del self._buf[:i + 1]
            if raw:
                lines.append(raw.decode("ascii", errors="replace"))
        if len(self._buf) > 512:          # garbage without newline: drop it
            self._buf.clear()
        return lines
