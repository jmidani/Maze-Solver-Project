"""
maze_gui.py - ECNG 4504 Phase 1 PC application (Tkinter + Bleak)

Run:   pip install -r requirements.txt
       python maze_gui.py

Features: BLE scan/connect/disconnect, TRAIN / SOLVE / STOP / RESET buttons,
live robot status, training and solving progress, final path display,
live maze-map drawing with the shortest path highlighted, error banner,
automatic reconnect, and a log file per session in ./logs/.
"""

import os
import queue
import time
import tkinter as tk
from tkinter import ttk

from ble_client import BleLink
from protocol import NF_DEADEND, NF_END, NF_START, NO_EXIT, UNEXPLORED, RobotModel

POLL_MS = 50
SILENCE_WARN_S = 3.0
RUNNING_STATES = ("TRAINING", "SOLVING", "RETURNING")


class MazeApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        root.title("ECNG 4504 Maze Robot - Phase 1")
        root.geometry("1100x720")

        self.events = queue.Queue()
        self.ble = BleLink(self.events)
        self.model = RobotModel()
        self.devices = []
        self.last_rx = 0.0
        self.mirror = tk.BooleanVar(value=False)

        os.makedirs("logs", exist_ok=True)
        self.log_path = os.path.join("logs", time.strftime("run_%Y%m%d_%H%M%S.txt"))
        self.log_file = open(self.log_path, "a", encoding="utf-8")

        self._build_ui()
        self._set_connected(False)
        root.protocol("WM_DELETE_WINDOW", self._on_close)
        root.after(POLL_MS, self._poll)

    # ================= UI =================
    def _build_ui(self):
        top = ttk.Frame(self.root, padding=6)
        top.pack(fill="x")
        ttk.Button(top, text="Scan", command=self._scan).pack(side="left")
        self.dev_combo = ttk.Combobox(top, width=42, state="readonly")
        self.dev_combo.pack(side="left", padx=4)
        self.btn_connect = ttk.Button(top, text="Connect", command=self._connect)
        self.btn_connect.pack(side="left")
        self.btn_disconnect = ttk.Button(top, text="Disconnect", command=self._disconnect)
        self.btn_disconnect.pack(side="left", padx=4)
        self.conn_label = ttk.Label(top, text="Disconnected", foreground="red", width=28)
        self.conn_label.pack(side="left", padx=8)
        ttk.Checkbutton(top, text="Mirror map", variable=self.mirror,
                        command=self._draw_map).pack(side="right")

        cmd = ttk.Frame(self.root, padding=(6, 0))
        cmd.pack(fill="x")
        self.cmd_buttons = []
        for text, c in [("TRAIN", "START_TRAIN"), ("SOLVE", "START_SOLVE"), ("STOP", "STOP"),
                        ("RESET", "RESET"), ("STATUS", "STATUS_REQUEST"),
                        ("GET MAP", "GET_MAP"), ("GET PATH", "GET_PATH"), ("CLEAR MAP", "CLEAR_MAP")]:
            b = ttk.Button(cmd, text=text, command=lambda c=c: self._send(c))
            b.pack(side="left", padx=2, pady=4)
            self.cmd_buttons.append(b)

        self.banner = tk.Label(self.root, text="", bg=self.root.cget("bg"), anchor="w")
        self.banner.pack(fill="x", padx=6)

        body = ttk.Frame(self.root, padding=6)
        body.pack(fill="both", expand=True)

        left = ttk.Frame(body)
        left.pack(side="left", fill="y")

        st = ttk.LabelFrame(left, text="Robot status", padding=6)
        st.pack(fill="x")
        self.status_vars = {}
        for i, (key, label) in enumerate([("mission", "Mission state"), ("nav", "Navigation state"),
                                          ("node", "Current node"), ("heading", "Heading"),
                                          ("nodes", "Nodes mapped"), ("frontiers", "Unexplored exits"),
                                          ("pos", "Position (cm)"), ("path_valid", "Path ready")]):
            ttk.Label(st, text=label + ":").grid(row=i, column=0, sticky="w")
            v = tk.StringVar(value="-")
            ttk.Label(st, textvariable=v, width=18, font=("Consolas", 10, "bold")).grid(row=i, column=1, sticky="w")
            self.status_vars[key] = v

        pr = ttk.LabelFrame(left, text="Progress", padding=6)
        pr.pack(fill="x", pady=6)
        ttk.Label(pr, text="Training").grid(row=0, column=0, sticky="w")
        self.train_bar = ttk.Progressbar(pr, length=220, maximum=100)
        self.train_bar.grid(row=0, column=1, padx=4)
        ttk.Label(pr, text="Solving").grid(row=1, column=0, sticky="w")
        self.solve_bar = ttk.Progressbar(pr, length=220, maximum=100)
        self.solve_bar.grid(row=1, column=1, padx=4)
        self.progress_text = ttk.Label(pr, text="")
        self.progress_text.grid(row=2, column=0, columnspan=2, sticky="w")

        pf = ttk.LabelFrame(left, text="Final path", padding=6)
        pf.pack(fill="x")
        self.path_text = tk.Text(pf, width=36, height=6, wrap="char", font=("Consolas", 10))
        self.path_text.pack(fill="x")

        right = ttk.Frame(body)
        right.pack(side="left", fill="both", expand=True, padx=(8, 0))
        self.canvas = tk.Canvas(right, bg="white", height=380)
        self.canvas.pack(fill="both", expand=True)
        self.canvas.bind("<Configure>", lambda e: self._draw_map())

        lf = ttk.LabelFrame(right, text="Log", padding=2)
        lf.pack(fill="both", expand=False, pady=(6, 0))
        self.log = tk.Text(lf, height=11, font=("Consolas", 9))
        sb = ttk.Scrollbar(lf, command=self.log.yview)
        self.log.configure(yscrollcommand=sb.set)
        self.log.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.log.tag_config("tx", foreground="blue")
        self.log.tag_config("err", foreground="red")
        self.log.tag_config("key", foreground="darkgreen")
        self.log.tag_config("dim", foreground="gray")

    # ================= actions =================
    def _scan(self):
        self.ble.scan(5.0)

    def _connect(self):
        i = self.dev_combo.current()
        if i < 0 or i >= len(self.devices):
            self._show_error("Select a device first (press Scan).")
            return
        self.conn_label.config(text="Connecting...", foreground="orange")
        self.ble.connect(self.devices[i][1])

    def _disconnect(self):
        self.ble.disconnect()

    def _send(self, cmd: str):
        if not self.ble.is_connected:
            self._show_error("Not connected")
            return
        self.ble.send(cmd)

    def _on_close(self):
        try:
            self.ble.auto_reconnect = False
            self.ble.disconnect()
            self.log_file.close()
        finally:
            self.root.after(300, self.root.destroy)

    # ================= event loop =================
    def _poll(self):
        try:
            while True:
                kind, payload = self.events.get_nowait()
                self._handle(kind, payload)
        except queue.Empty:
            pass

        # Watchdog: robot running but silent
        if self.ble.is_connected and self.model.mission in RUNNING_STATES and self.last_rx:
            if time.time() - self.last_rx > SILENCE_WARN_S:
                self._show_error("No data from robot for %.0f s" % (time.time() - self.last_rx))
        self.root.after(POLL_MS, self._poll)

    def _handle(self, kind, payload):
        if kind == "devices":
            self.devices = payload
            self.dev_combo["values"] = ["%s%s  [%s]  %s dBm" % ("* " if d[3] else "", d[0], d[1], d[2])
                                        for d in payload]
            if payload:
                self.dev_combo.current(0)
            self._log("Found %d devices (* = likely HM-10)" % len(payload), "dim")
        elif kind == "connected":
            self._set_connected(True, payload)
            self._clear_error()
            self._log("Connected to %s" % payload, "key")
            self.ble.send("STATUS_REQUEST")
            self.ble.send("GET_PATH")
        elif kind == "disconnected":
            self._set_connected(False)
            if payload != "user":
                self._show_error("BLE link lost - the robot keeps running; reconnecting...")
            self._log("Disconnected (%s)" % payload, "err")
        elif kind == "line":
            self.last_rx = time.time()
            self._on_line(payload)
        elif kind == "sent":
            self._log(">> " + payload, "tx")
        elif kind == "error":
            self._show_error(payload)
            self._log("!! " + payload, "err")
        elif kind == "info":
            self._log(payload, "dim")

    def _on_line(self, line: str):
        ev = self.model.feed(line)
        t = ev["type"] if ev else "none"
        quiet = t in ("status", "nav") or line.startswith("DIAG:") or line.startswith("MAP:N") \
            or line.startswith("FINAL_PATH:")
        if not quiet:
            self._log(line, "err" if t == "error" else ("key" if t == "phase" else None))
        else:
            self._write_file(line)

        if t in ("status", "ready", "nav", "event"):
            self._refresh_status()
            if t == "event" and ev["name"] in ("NODE_NEW", "EXP_BEGIN", "LOOP_CLOSED"):
                self._draw_map()
        elif t == "error":
            self._show_error("Robot error: %s %s" % (ev["code"], ev["detail"]))
        elif t == "phase":
            name = ev["name"]
            if name == "TRAINING_STARTED":
                self._clear_error()
                self.path_text.delete("1.0", "end")
                self.solve_bar["value"] = 0
            elif name == "TRAINING_COMPLETED":
                self.train_bar["value"] = 100
                self._banner("Training completed", "darkgreen")
            elif name == "SOLVING_STARTED":
                self._clear_error()
                self.solve_bar["value"] = 0
            elif name == "SOLVING_COMPLETED":
                self.solve_bar["value"] = 100
                self._banner("SOLVED - destination reached", "darkgreen")
            self._refresh_status()
            self._draw_map()
        elif t == "map":
            self._draw_map()
            if not ev["complete"]:
                self._log("Map dump incomplete (lines lost) - press GET MAP", "err")
        elif t == "path":
            self._show_path()
            self._draw_map()
            if not ev["complete"]:
                self._log("Path dump incomplete - press GET PATH", "err")
            if not any(n.linked for n in self.model.map_nodes.values()):
                self.ble.send("GET_MAP")      # path known but no full map yet

    # ================= display =================
    def _refresh_status(self):
        m = self.model
        cm = m.units_per_cm or 1.0
        v = self.status_vars
        v["mission"].set(m.mission)
        v["nav"].set(m.nav)
        v["node"].set("-" if m.node >= 254 else str(m.node))
        v["heading"].set(m.heading)
        v["nodes"].set(str(m.nodes))
        v["frontiers"].set(str(m.frontiers))
        v["pos"].set("%.0f, %.0f" % (m.x / cm, m.y / cm))
        v["path_valid"].set("YES" if m.path_valid else "no")

        if m.mission == "TRAINING":
            denom = m.nodes + m.frontiers
            self.train_bar["value"] = 100.0 * m.nodes / denom if denom else 0
            self.progress_text.config(text="Exploring: %d nodes, %d exits left" % (m.nodes, m.frontiers))
        elif m.mission in ("SOLVING", "COMPLETED") and m.total > 1:
            self.solve_bar["value"] = 100.0 * m.step / (m.total - 1)
            self.progress_text.config(text="Solving: node %d of %d" % (m.step, m.total - 1))

    def _show_path(self):
        m = self.model
        self.path_text.delete("1.0", "end")
        self.path_text.insert("end", "Actions (%d): %s\n" % (len(m.path_actions), m.path_actions))
        self.path_text.insert("end", "Nodes: %s\n" % " > ".join(str(n) for n in m.path_nodes))
        self.path_text.insert("end", "Cost: %d%s\n" % (m.path_cost, "  (PARTIAL MAP)" if m.path_partial else ""))
        self.path_text.insert("end", "S=straight L=left R=right U=u-turn")

    def _draw_map(self):
        c = self.canvas
        c.delete("all")
        nodes = self.model.map_nodes
        if not nodes:
            c.create_text(10, 10, anchor="nw", text="No map yet - press TRAIN", fill="gray")
            return
        w, h = max(c.winfo_width(), 100), max(c.winfo_height(), 100)
        xs = [n.x for n in nodes.values()]
        ys = [n.y for n in nodes.values()]
        pad = 40
        span = max(max(xs) - min(xs), max(ys) - min(ys), 1)
        scale = min((w - 2 * pad) / span, (h - 2 * pad) / span)
        mirror = -1 if self.mirror.get() else 1
        cx, cy = (max(xs) + min(xs)) / 2, (max(ys) + min(ys)) / 2

        def P(n):
            return (w / 2 + mirror * (n.x - cx) * scale, h / 2 - (n.y - cy) * scale)

        path = self.model.path_nodes
        path_edges = set()
        for a, b in zip(path, path[1:]):
            path_edges.add((a, b))
            path_edges.add((b, a))

        stub = 18
        dx = [0, 1, 0, -1]
        dy = [-1, 0, 1, 0]   # canvas y grows downward
        for n in nodes.values():
            x1, y1 = P(n)
            for d in range(4):
                t = n.nbr[d]
                if t == NO_EXIT:
                    continue
                if t == UNEXPLORED:
                    c.create_line(x1, y1, x1 + mirror * dx[d] * stub, y1 + dy[d] * stub,
                                  fill="orange", width=2, dash=(3, 2))
                elif t in nodes and t > n.id:
                    x2, y2 = P(nodes[t])
                    on_path = (n.id, t) in path_edges
                    c.create_line(x1, y1, x2, y2, fill="green" if on_path else "black",
                                  width=6 if on_path else 2)

        for n in nodes.values():
            x, y = P(n)
            r = 7
            color = "white"
            if n.flags & NF_START:
                color, r = "deepskyblue", 10
            elif n.flags & NF_END:
                color, r = "red", 10
            elif n.flags & NF_DEADEND:
                color = "gray"
            outline = "magenta" if n.id == self.model.node else "black"
            c.create_oval(x - r, y - r, x + r, y + r, fill=color, outline=outline,
                          width=3 if n.id == self.model.node else 1)
            c.create_text(x + 12, y - 10, text=str(n.id), font=("Arial", 8))

        legend = "blue=start  red=end  gray=dead end  orange=unexplored  green=shortest path  magenta=robot"
        c.create_text(6, h - 6, anchor="sw", text=legend, fill="gray", font=("Arial", 8))

    # ================= helpers =================
    def _set_connected(self, on: bool, addr: str = ""):
        self.conn_label.config(text=("Connected " + addr) if on else "Disconnected",
                               foreground="green" if on else "red")
        for b in self.cmd_buttons:
            b.state(["!disabled"] if on else ["disabled"])
        self.btn_disconnect.state(["!disabled"] if on else ["disabled"])

    def _banner(self, text, color):
        self.banner.config(text=text, fg="white", bg=color)

    def _show_error(self, text):
        self.banner.config(text="  " + text, fg="white", bg="firebrick")

    def _clear_error(self):
        self.banner.config(text="", bg=self.root.cget("bg"))

    def _write_file(self, line):
        self.log_file.write("%s %s\n" % (time.strftime("%H:%M:%S"), line))
        self.log_file.flush()

    def _log(self, text, tag=None):
        self._write_file(text)
        self.log.insert("end", time.strftime("%H:%M:%S ") + text + "\n", tag or ())
        if int(self.log.index("end-1c").split(".")[0]) > 2000:
            self.log.delete("1.0", "500.0")
        self.log.see("end")


def main():
    root = tk.Tk()
    try:
        ttk.Style().theme_use("vista")
    except tk.TclError:
        pass
    MazeApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
