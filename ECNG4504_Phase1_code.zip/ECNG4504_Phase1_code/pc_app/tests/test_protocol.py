"""Offline test of protocol.py: feeds lines in the exact formats the firmware
prints (mission.cpp), split into 20-byte BLE packets like the HM-10 does."""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from protocol import LineAssembler, RobotModel  # noqa: E402

LINES = [
    "BOOT",
    "ROBOT_READY:0,0,READY",
    "ACK:START_TRAIN",
    "EVT:MISSION,TRAINING",
    "TRAINING_STARTED",
    "EVT:EXP_BEGIN",
    "NAV:FOLLOW",
    "EVT:NODE_NEW,1,0,-450,15,0",
    "CURRENT_STATUS:TRAINING,JUNCTION_PASS,1,S,2,3,0/0,0,-455,0",
    "DIAG:00100,0,75,75",
    "EVT:LOOP_CLOSED,6,3",
    "EVT:NODE_NEW,2,0,-1050,3,2",
    "EVT:END_FOUND,2",
    "TRAINING_COMPLETED:3,1,95,0",
    "FINAL_PATH:BEGIN,3,1,95,0",
    "FINAL_PATH:A,S",
    "FINAL_PATH:N,0,1,2",
    "FINAL_PATH:END",
    "MAP:BEGIN,3,0,2,2,150",
    "MAP:N,0,0,0,255,255,1,255,1",
    "MAP:N,1,0,-450,0,254,2,254,0",
    "MAP:N,2,0,-1050,1,255,255,255,2",
    "MAP:END",
    "ERROR:NAV_FAILED,SEARCH_FAILED",
    "SOLVING_STARTED",
    "CURRENT_STATUS:SOLVING,FOLLOW,1,S,3,2,1/3,0,-500,1",
    "SOLVING_COMPLETED",
]

stream = "".join(l + "\n" for l in LINES).encode()
asm, model, events = LineAssembler(), RobotModel(), []
for i in range(0, len(stream), 20):                 # 20-byte notifications
    for line in asm.push(stream[i:i + 20]):
        events.append(model.feed(line))

types = [e["type"] for e in events if e]
assert len(events) == len(LINES), (len(events), len(LINES))
assert "bad" not in types, types
assert model.path_actions == "S" and model.path_nodes == [0, 1, 2] and model.path_cost == 95
assert len(model.map_nodes) == 3 and model.map_nodes[1].nbr == [0, 254, 2, 254]
assert model.start_node == 0 and model.end_node == 2 and model.units_per_cm == 15.0
assert model.mission == "SOLVING" and model.step == 3 and model.total == 3
err = [e for e in events if e and e["type"] == "error"][0]
assert err["code"] == "NAV_FAILED" and err["detail"] == "SEARCH_FAILED"
print("protocol test OK:", len(events), "lines parsed;", sorted(set(types)))
