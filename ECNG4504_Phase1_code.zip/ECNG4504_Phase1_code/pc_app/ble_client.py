"""
ble_client.py - Bleak BLE client for the HM-10 running in a background thread.

The HM-10 exposes one service (FFE0) with one characteristic (FFE1) that
is used both ways: writes go to the robot UART, notifications carry the
robot's UART output. Bleak is asyncio-based; it runs in its own thread with
its own event loop so the Tkinter GUI never freezes. Results go back to the
GUI through a thread-safe queue as (kind, payload) tuples:

    ("devices", [(name, address, rssi), ...])
    ("connected", address)        ("disconnected", reason)
    ("line", text)                ("error", message)
    ("info", message)
"""

import asyncio
import queue
import threading
from typing import Optional

from bleak import BleakClient, BleakScanner

from protocol import LineAssembler

HM10_SERVICE = "0000ffe0-0000-1000-8000-00805f9b34fb"
HM10_CHAR = "0000ffe1-0000-1000-8000-00805f9b34fb"
LIKELY_NAMES = ("HMSOFT", "HM-10", "HM10", "BT05", "MLT-BT05", "JDY", "CC41", "ROBOT", "MAZE")


class BleLink:
    def __init__(self, events: "queue.Queue"):
        self.events = events
        self.loop = asyncio.new_event_loop()
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()
        self.client: Optional[BleakClient] = None
        self.address: Optional[str] = None
        self.assembler = LineAssembler()
        self.write_response = False
        self.user_disconnect = False
        self.auto_reconnect = True

    # ---------- thread plumbing ----------
    def _run(self):
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()

    def _submit(self, coro):
        return asyncio.run_coroutine_threadsafe(coro, self.loop)

    def _emit(self, kind, payload=None):
        self.events.put((kind, payload))

    # ---------- public API (called from GUI thread) ----------
    def scan(self, timeout: float = 5.0):
        self._submit(self._scan(timeout))

    def connect(self, address: str):
        self.user_disconnect = False
        self._submit(self._connect(address))

    def disconnect(self):
        self.user_disconnect = True
        self._submit(self._disconnect())

    def send(self, text: str):
        self._submit(self._send(text))

    @property
    def is_connected(self) -> bool:
        return self.client is not None and self.client.is_connected

    # ---------- coroutines ----------
    async def _scan(self, timeout: float):
        try:
            self._emit("info", "Scanning for %.0f s..." % timeout)
            found = []
            try:
                result = await BleakScanner.discover(timeout=timeout, return_adv=True)
                for addr, (dev, adv) in result.items():
                    name = dev.name or adv.local_name or "?"
                    uuids = [u.lower() for u in (adv.service_uuids or [])]
                    likely = HM10_SERVICE in uuids or any(k in name.upper() for k in LIKELY_NAMES)
                    found.append((name, addr, adv.rssi, likely))
            except TypeError:  # very old Bleak without return_adv
                for dev in await BleakScanner.discover(timeout=timeout):
                    name = dev.name or "?"
                    found.append((name, dev.address, getattr(dev, "rssi", 0),
                                  any(k in name.upper() for k in LIKELY_NAMES)))
            found.sort(key=lambda t: (not t[3], -(t[2] or -999)))
            self._emit("devices", found)
        except Exception as e:  # noqa: BLE001 - report every scan problem to the GUI
            self._emit("error", "Scan failed: %s" % e)

    def _on_disconnect(self, _client):
        # Called by Bleak in its loop when the link drops
        self._emit("disconnected", "user" if self.user_disconnect else "link lost")
        if not self.user_disconnect and self.auto_reconnect and self.address:
            self.loop.create_task(self._reconnect())

    async def _reconnect(self):
        for attempt in range(1, 6):
            if self.user_disconnect:
                return
            self._emit("info", "Reconnecting (attempt %d/5)..." % attempt)
            await asyncio.sleep(2.0)
            if await self._connect(self.address, quiet=True):
                return
        self._emit("error", "Reconnect failed. Press Connect to try again.")

    async def _connect(self, address: str, quiet: bool = False) -> bool:
        try:
            if self.client is not None and self.client.is_connected:
                await self.client.disconnect()
            self.address = address
            self.assembler = LineAssembler()
            self.client = BleakClient(address, disconnected_callback=self._on_disconnect)
            await self.client.connect(timeout=15.0)

            char = self.client.services.get_characteristic(HM10_CHAR)
            if char is None:
                raise RuntimeError("FFE1 characteristic not found (is this an HM-10?)")
            # Prefer write-without-response (faster); some clones only support write
            self.write_response = "write-without-response" not in char.properties
            await self.client.start_notify(HM10_CHAR, self._on_notify)
            self._emit("connected", address)
            return True
        except Exception as e:  # noqa: BLE001
            if not quiet:
                self._emit("error", "Connect failed: %s" % e)
            return False

    async def _disconnect(self):
        try:
            if self.client is not None and self.client.is_connected:
                await self.client.disconnect()
        except Exception as e:  # noqa: BLE001
            self._emit("error", "Disconnect error: %s" % e)

    def _on_notify(self, _sender, data: bytearray):
        for line in self.assembler.push(bytes(data)):
            self._emit("line", line)

    async def _send(self, text: str):
        if not self.is_connected:
            self._emit("error", "Not connected: '%s' not sent" % text)
            return
        try:
            payload = (text.strip() + "\n").encode("ascii")
            # HM-10 forwards at most 20 bytes per packet; commands are short
            for i in range(0, len(payload), 20):
                await self.client.write_gatt_char(HM10_CHAR, payload[i:i + 20],
                                                  response=self.write_response)
            self._emit("sent", text)
        except Exception as e:  # noqa: BLE001
            self._emit("error", "Send failed: %s" % e)
