// =====================================================================
//  sim.cpp  -  Host (PC) test of the maze logic using the REAL firmware
//              files maze_map.cpp, explorer.cpp, path_exec.cpp.
//
//  A ground-truth maze is simulated at node level. Each edge driven is
//  measured with random odometry error (default +/-10 %), so loop closure
//  is tested under drift. For every random seed the test checks:
//    1. exploration finishes (DONE),
//    2. every map node corresponds to exactly one real node (no duplicates),
//    3. the computed path has the same cost as the true shortest path,
//    4. executing the route from the start reaches the end circle.
//
//  Build (one line):
//    g++ -std=c++11 -O2 -I../../MazeRobot sim.cpp ../../MazeRobot/maze_map.cpp
//        ../../MazeRobot/explorer.cpp ../../MazeRobot/path_exec.cpp -o sim
//  Run:    ./sim [noise_percent] [runs] [verbose]
// =====================================================================
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <vector>
#include <string>
#include "config.h"
#include "maze_map.h"
#include "explorer.h"
#include "path_exec.h"

static bool gVerbose = false;
void mazeLog(const char* msg) { if (gVerbose) printf("    [log] %s\n", msg); }

// ---------------- ground-truth maze ----------------
struct TNode { const char* name; int x, y; int nbr[4]; bool circle; };
struct TMaze { std::vector<TNode> n; int start, end; const char* title; };

static int addN(TMaze& m, const char* name, int x, int y, bool circle = false) {
  TNode t; t.name = name; t.x = x; t.y = y; t.circle = circle;
  for (int d = 0; d < 4; d++) t.nbr[d] = -1;
  m.n.push_back(t);
  return (int)m.n.size() - 1;
}
static void edge(TMaze& m, int a, int b) {           // axis-aligned edge, direction inferred
  int dx = m.n[b].x - m.n[a].x, dy = m.n[b].y - m.n[a].y;
  int d = (dx > 0) ? DIR_E : (dx < 0) ? DIR_W : (dy > 0) ? DIR_N : DIR_S;
  m.n[a].nbr[d] = b;
  m.n[b].nbr[dirBack(d)] = a;
}
static int tlen(const TMaze& m, int a, int b) {
  return abs(m.n[a].x - m.n[b].x) + abs(m.n[a].y - m.n[b].y);
}

// Maze 1: two boxes (loops) at the top, like the Phase 0 track; dead ends below.
static TMaze maze1() {
  TMaze m; m.title = "two-box loops + dead ends";
  int S  = addN(m, "START", 75, 190, true);
  int J1 = addN(m, "J1", 75, 160);
  int A  = addN(m, "A", 30, 160), B = addN(m, "B", 120, 160);
  int C  = addN(m, "C", 75, 120), D = addN(m, "D", 30, 120), E = addN(m, "E", 120, 120);
  int F  = addN(m, "F", 75, 80),  G = addN(m, "G", 30, 80),  H = addN(m, "H", 120, 80);
  int K  = addN(m, "K", 75, 40),  L = addN(m, "L", 30, 40),  I = addN(m, "I", 120, 40);
  int EN = addN(m, "END", 120, 10, true);
  edge(m,S,J1); edge(m,J1,A); edge(m,J1,B); edge(m,J1,C); edge(m,A,D); edge(m,D,C);
  edge(m,B,E); edge(m,E,C); edge(m,C,F); edge(m,F,G); edge(m,F,H); edge(m,H,I);
  edge(m,F,K); edge(m,K,I); edge(m,K,L); edge(m,I,EN);
  m.start = S; m.end = EN;
  return m;
}

// Maze 2: dense 4x4 grid (many loops), with a few edges removed.
static TMaze maze2() {
  TMaze m; m.title = "4x4 grid, many loops";
  static char names[16][4];
  int g[4][4];
  for (int r = 0; r < 4; r++) for (int c = 0; c < 4; c++) {
    snprintf(names[r*4+c], 4, "%c%d", 'a' + r, c);
    g[r][c] = addN(m, names[r*4+c], 20 + c * 35, 170 - r * 40);
  }
  int S = addN(m, "START", 20, 200, true);
  int EN = addN(m, "END", 125, 20, true);
  edge(m, S, g[0][0]);
  edge(m, g[3][3], EN);
  for (int r = 0; r < 4; r++) for (int c = 0; c < 4; c++) {
    if (c < 3 && !(r == 1 && c == 1) && !(r == 2 && c == 2)) edge(m, g[r][c], g[r][c+1]);
    if (r < 3 && !(r == 0 && c == 2) && !(r == 2 && c == 0)) edge(m, g[r][c], g[r+1][c]);
  }
  m.start = S; m.end = EN;
  return m;
}

// True shortest cost with the same cost function as the firmware
static long trueShortest(const TMaze& m) {
  int N = (int)m.n.size();
  std::vector<long> dist(N, 1L << 40);
  std::vector<bool> done(N, false);
  dist[m.start] = 0;
  for (;;) {
    int u = -1;
    for (int i = 0; i < N; i++) if (!done[i] && (u < 0 || dist[i] < dist[u])) u = i;
    if (u < 0 || dist[u] >= (1L << 40)) break;
    done[u] = true;
    for (int d = 0; d < 4; d++) {
      int v = m.n[u].nbr[d];
      if (v < 0) continue;
      long c = USE_EDGE_LENGTHS ? (tlen(m, u, v) + NODE_COST_CM) : 1;
      if (dist[u] + c < dist[v]) dist[v] = dist[u] + c;
    }
  }
  return dist[m.end];
}

static double frand() { return (double)rand() / RAND_MAX; }

struct Robot { int tnode; uint8_t heading; double ex, ey; };

static NodeObs observe(const TMaze& m, int t, uint8_t heading, double ex, double ey) {
  NodeObs o;
  o.x = (int32_t)lround(ex);
  o.y = (int32_t)lround(ey);
  o.heading = heading;
  o.exitMask = 0;
  int deg = 0;
  for (int d = 0; d < 4; d++) if (m.n[t].nbr[d] >= 0) { o.exitMask |= dirBit(d); deg++; }
  if (m.n[t].circle) { o.kind = OBS_CIRCLE; o.exitMask = dirBit(dirBack(heading)); }
  else if (deg == 1) { o.kind = OBS_DEADEND; o.exitMask = dirBit(dirBack(heading)); }
  else o.kind = OBS_JUNCTION;
  return o;
}

// Drive one edge: returns measured length in odometry units
static double drive(const TMaze& m, Robot& r, uint8_t dir, double noise) {
  int nxt = m.n[r.tnode].nbr[dir];
  if (nxt < 0) { printf("    !! robot told to drive into nothing\n"); exit(2); }
  double meas = tlen(m, r.tnode, nxt) * ODO_UNITS_PER_CM * (1.0 + noise * (2 * frand() - 1));
  r.ex += DIR_DX[dir] * meas;
  r.ey += DIR_DY[dir] * meas;
  r.tnode = nxt;
  r.heading = dir;
  return meas;
}

static bool runOnce(const TMaze& m, double noise, unsigned seed, std::string& why, int& steps) {
  srand(seed);
  Robot r;
  r.tnode = m.start;
  r.heading = START_HEADING;
  r.ex = 0; r.ey = 0;
  // Start node position in the true maze, so real node positions map to estimated ones
  double ox = m.n[m.start].x, oy = m.n[m.start].y;
  (void)ox; (void)oy;

  expBegin(0, 0, START_HEADING);
  std::vector<int> map2true(MAX_NODES, -1);
  map2true[gMap.startNode] = m.start;

  uint8_t dir = START_HEADING;
  steps = 0;
  for (;;) {
    if (++steps > 2000) { why = "too many steps"; return false; }
    drive(m, r, dir, noise);
    NodeObs o = observe(m, r.tnode, r.heading, r.ex, r.ey);
    int32_t nx, ny;
    uint8_t out = NO_EXIT;
    StepResult res = expOnNode(o, &out, &nx, &ny);
    r.ex += nx - o.x;   // snap like mission.cpp
    r.ey += ny - o.y;

    uint8_t id = expCurrentNode();
    if (map2true[id] < 0) map2true[id] = r.tnode;
    else if (map2true[id] != r.tnode) { why = "WRONG MATCH (two real nodes merged)"; return false; }
    if (gVerbose) printf("  at %-5s -> map %u  res=%d out=%c\n", m.n[r.tnode].name, id, res,
                         out < 4 ? DIR_CHARS[out] : '-');

    if (res == STEP_DONE) break;
    if (res == STEP_FAIL) { why = "explorer FAIL"; return false; }
    dir = out;
  }

  // 2. duplicates
  if (gMap.count != (uint8_t)m.n.size()) {
    char b[80]; snprintf(b, sizeof(b), "map has %u nodes, maze has %zu (duplicates)", gMap.count, m.n.size());
    why = b; return false;
  }
  if (!mapValidate()) { why = "map inconsistent"; return false; }

  // 3. shortest path
  uint8_t path[MAX_NODES]; uint16_t cost;
  uint8_t n = mapShortestPath(gMap.startNode, gMap.endNode, path, MAX_NODES, &cost);
  if (n < 2) { why = "no path"; return false; }
  long trueCost = 0;
  for (uint8_t i = 0; i + 1 < n; i++) {
    int a = map2true[path[i]], b = map2true[path[i + 1]];
    trueCost += USE_EDGE_LENGTHS ? tlen(m, a, b) + NODE_COST_CM : 1;
  }
  long best = trueShortest(m);
  // Measured lengths are noisy, so allow a path whose TRUE cost is within noise of optimal
  if (trueCost > best * (1.0 + noise) + 1) {
    char b[80]; snprintf(b, sizeof(b), "path cost %ld vs optimal %ld", trueCost, best);
    why = b; return false;
  }

  // 4. execute the route from the start
  execBegin(path, n);
  r.tnode = m.start; r.heading = START_HEADING; r.ex = 0; r.ey = 0;
  dir = gMap.startHeading;
  for (int k = 0; k < 200; k++) {
    drive(m, r, dir, noise);
    NodeObs o = observe(m, r.tnode, r.heading, r.ex, r.ey);
    int32_t nx, ny; bool snap; uint8_t out = NO_EXIT;
    StepResult res = execOnNode(o, &out, &nx, &ny, &snap);
    if (snap) { r.ex += nx - o.x; r.ey += ny - o.y; }
    if (res == STEP_DONE) {
      if (r.tnode != m.end) { why = "solve stopped at wrong node"; return false; }
      return true;
    }
    if (res == STEP_FAIL) { why = "solve FAIL"; return false; }
    dir = out;
  }
  why = "solve did not finish";
  return false;
}

static void printExample(const TMaze& m) {
  gVerbose = false;
  std::string why; int steps;
  runOnce(m, 0.0, 1, why, steps);
  printf("\n  Graph built for '%s' (noise 0):\n", m.title);
  printf("  id  x(u)   y(u)   N   E   S   W  flags\n");
  for (uint8_t i = 0; i < gMap.count; i++) {
    const MazeNode& n = gMap.node[i];
    printf("  %2u %6d %6d", i, n.x, n.y);
    for (int d = 0; d < 4; d++) {
      if (n.nbr[d] == NO_EXIT) printf("   .");
      else if (n.nbr[d] == UNEXPLORED) printf("   ?");
      else printf(" %3u", n.nbr[d]);
    }
    printf("  %s%s%s\n", (n.flags & NF_START) ? "START " : "", (n.flags & NF_END) ? "END " : "",
           (n.flags & NF_DEADEND) ? "DEADEND" : "");
  }
  uint8_t path[MAX_NODES]; uint16_t cost;
  uint8_t n = mapShortestPath(gMap.startNode, gMap.endNode, path, MAX_NODES, &cost);
  printf("  Shortest path nodes:");
  for (uint8_t i = 0; i < n; i++) printf(" %u", path[i]);
  printf("   actions: ");
  for (uint8_t i = 1; i + 1 < n; i++)
    printf("%c", relFromAbs(mapDirTo(path[i - 1], path[i]), mapDirTo(path[i], path[i + 1])));
  printf("   cost=%u  exploration steps=%d\n", cost, steps);
}

int main(int argc, char** argv) {
  double noise = (argc > 1) ? atof(argv[1]) / 100.0 : 0.10;
  int runs = (argc > 2) ? atoi(argv[2]) : 200;
  gVerbose = (argc > 3);

  TMaze mazes[2] = {maze1(), maze2()};
  int totalFail = 0;
  for (int k = 0; k < 2; k++) {
    int ok = 0, stepsSum = 0;
    std::string firstFail;
    for (int s = 0; s < runs; s++) {
      std::string why; int steps = 0;
      if (runOnce(mazes[k], noise, 1000 + s, why, steps)) { ok++; stepsSum += steps; }
      else if (firstFail.empty()) firstFail = why + " (seed " + std::to_string(1000 + s) + ")";
    }
    printf("Maze %d (%s): %d/%d runs OK at +/-%.0f%% odometry noise, avg %d edges driven in training\n",
           k + 1, mazes[k].title, ok, runs, noise * 100, ok ? stepsSum / ok : 0);
    if (!firstFail.empty()) printf("  first failure: %s\n", firstFail.c_str());
    totalFail += runs - ok;
  }
  printExample(mazes[0]);
  return totalFail ? 1 : 0;
}
