// =====================================================================
//  MazeRobot.ino  -  ECNG 4504 Phase 1 (single-file version)
//
//  Same code as the modular version, merged into one file. Sections, in order:
//    config, types/declarations, motors, sensors, maze_map (graph + Dijkstra/BFS),
//    odometry, explorer (training), path_exec (solving), storage (EEPROM),
//    ble_link (HM-10 protocol), nav (Phase 0 motion FSM), mission (top FSM),
//    setup()/loop().
// =====================================================================
#include <Arduino.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <EEPROM.h>
#include <avr/eeprom.h>

// #####################################################################
//  config.h
// #####################################################################
// =====================================================================
//  config.h  -  All pins and tuning constants (ECNG 4504 Phase 1)
//
//  Pins, motor inversion, sensor polarity, speeds and timings are copied
//  UNCHANGED from the Phase 0 sketch. Everything marked "NEW (Phase 1)"
//  was added for mapping, solving and BLE.
//
//  This header has no Arduino dependency on purpose, so the maze modules
//  (maze_map / explorer / path_exec) can also be compiled on a PC for the
//  host simulation test.
// =====================================================================

// ================= PINS (Phase 0, unchanged) =================
#define MOTOR_L_PWM 5
#define MOTOR_L_IN1 6
#define MOTOR_L_IN2 7

#define MOTOR_R_PWM 9
#define MOTOR_R_IN3 10
#define MOTOR_R_IN4 11

const uint8_t SENSOR_PINS[5] = {32, 24, 26, 28, 30};
#define STATUS_LED 13

// HM-10 on Serial1: Mega TX1 = 18 -> (1k/2k divider) -> HM-10 RX
//                   Mega RX1 = 19 <- HM-10 TX

// ================= CONFIG (Phase 0, unchanged) =================
const bool SENSOR_TEST_MODE = false;
const bool LINE_IS_BLACK = true;

const bool INVERT_L = true;
const bool INVERT_R = false;

// Default motor trims. The values actually used can be changed over BLE/USB
// with TRIM_L:<percent> / TRIM_R:<percent> and are saved in EEPROM.
const float TRIM_LEFT = 1.00f;
const float TRIM_RIGHT = 1.00f;

// Speeds
const int MOTOR_LIMIT = 255;
const int SPEED_BASE = 75;
const int SPEED_MIN = 0;
const int SPEED_MAX = 130;
const int SPEED_KICK = 180;          // was 255: the start-up current spike reset the Mega
const int SPEED_TURN = 200;
const int SPEED_TURN_FINE = 140;
const int SPEED_REALIGN = 140;
const int SPEED_LOST_OUTER = 120;
const int SPEED_LOST_INNER = -60;
const int SPEED_UTURN = 240;
const int SPEED_UTURN_FINE = 170;
const int SPEED_TANK_DRIVE = 70;
const int SPEED_TANK_ROT = 120;
const int SPEED_SEARCH = 90;
const int SEARCH_ARC = 80;
const int SPEED_END_CHECK = 100;

// PD controller
const float KP_GAIN = 25.0f;
const float KD_GAIN = 8.0f;
const float LEFT_BIAS = 1.0f;
const unsigned long CONTROL_MS = 5;

// Timing
const unsigned long TURN_ALIGN_MS = 70;
const long ALIGN_BACK_MAX_MS = 150;
const unsigned long TURN_KICK_MS = 60;
const unsigned long TURN_MIN_MS = 120;
const unsigned long TURN_FINE_TIMEOUT = 400;
const unsigned long TURN_BRAKE_MS = 30;
const unsigned long POST_TURN_GRACE_MS = 300;
const unsigned long REALIGN_TIMEOUT = 500;
const unsigned long LOST_HOLD_MS = 400;
const unsigned long DEADEND_CHECK_MS = 300;
const unsigned long TIMEOUT_TURN = 1200;
const unsigned long TIMEOUT_CLEAR = 700;
const unsigned long LOCKOUT_JUNCTION = 350;
const unsigned long CONFIRM_CLEAR = 100;
const unsigned long UTURN_MIN_TIME = 300;
const unsigned long UTURN_MAX_TIME = 2500;
const unsigned long PRINT_INTERVAL = 150;
const unsigned long END_ZONE_MS = 400;
const unsigned long END_CHECK_MS = 250;
const unsigned long JUNCTION_PASS_TIMEOUT = 600;
const unsigned long SEARCH_STEP_MS = 200;
const unsigned long SEARCH_STEP_GROW = 80;
const uint8_t SEARCH_MAX_STEPS = 15;
const unsigned long TANK_STEP_MS = 180;
const unsigned long TANK_MIN_MS = 150;
const unsigned long TANK_360_MS = 4000;     // time for one full tank rotation (tune on the mat)

// Detection
const uint8_t CONFIRM_READS = 2;
const unsigned long JUNCTION_CONFIRM_MS = 35;
// NEW (Phase 1): when the line is off-centre (PD wobble), a 3-sensor mark is
// usually the line sliding under the side of the bar, not a branch: require
// the mark to last longer before it counts.
const float JUNCTION_OFFCENTER_ERR = 0.9f;
const unsigned long JUNCTION_CONFIRM_OFFCENTER_MS = 80;
const float DEADEND_ERR_MAX = 0.25f;

// ================= NEW (Phase 1): line-loss filtering =================
// All-white must last at least this long (in addition to CONFIRM_READS)
// before it counts. Fixes false dead ends from single white readings.
const unsigned long WHITE_CONFIRM_MS = 15;

// After DEADEND_CHECK, sweep left/right before accepting a dead end.
// If the line is found, it was a line slip, not a dead end.
const bool DEADEND_SWEEP_ENABLE = true;
const unsigned long DEADEND_SWEEP_MS = 120;   // each half-sweep (tune: about 25-35 degrees)

// ================= NEW (Phase 1): leaving a black circle =================
// Used to U-turn out of the end circle during training, and out of the
// start circle if the robot returned there facing inward.
const unsigned long CIRCLE_CLEAR_MS = 40;       // not-all-black this long = bar is out of the disc
const unsigned long CIRCLE_EXTRA_MS = 250;      // keep reversing so the spin does not touch the disc
const unsigned long CIRCLE_EXIT_TIMEOUT = 2500;

// ================= NEW (Phase 1): odometry (no encoders) =================
// Distance is estimated by integrating the commanded PWM over time:
//   1 odometry unit = ODO_SCALE PWM*ms of average wheel command.
const long ODO_SCALE = 100;

// CALIBRATE: drive a straight 100 cm line, send ODO, divide dist by 100.
const float ODO_UNITS_PER_CM = 15.0f;

// The Phase 0 turn logic puts the axle over the junction centre after a
// total forward travel of TURN_ALIGN_MS at SPEED_BASE from detection.
// So: junction centre = position at detection + ALIGN_UNITS along heading.
const long ALIGN_UNITS = (long)TURN_ALIGN_MS * SPEED_BASE / ODO_SCALE;

// Rotation estimate used only to recover the heading after a tank turn.
// Starting guess in PWM*ms per 90 degrees, auto-calibrated on clean turns.
const long ROT_PER_90_DEFAULT = 60000L;

// ================= NEW (Phase 1): maze mapping =================
// Heading codes: 0 = N, 1 = E, 2 = S, 3 = W. The robot starts facing "down".
const uint8_t START_HEADING = 2;

// Node matching tolerances (loop closure). For each stored node the tolerance
// grows by TOL_DRIFT_FRAC of the distance driven since the robot was last at
// that node, because odometry drift grows with distance.
const float TOL_PERP_CM = 8.0f;
const float TOL_DRIFT_FRAC = 0.10f;
const float TOL_ALONG_CM = 10.0f;
const float TOL_ALONG_FRAC = 0.25f;

// Shortest path: true = Dijkstra on measured edge length (+ NODE_COST_CM per
// node, so fewer junctions/turns is preferred); false = plain BFS (hop count).
const bool USE_EDGE_LENGTHS = true;
const uint16_t NODE_COST_CM = 10;

// Exploration budget: once the end is found, stop exploring after this.
const unsigned long TRAIN_MAX_MS = 240000UL;

// true = after training, drive back to the start circle autonomously.
// false = stop where exploration ends (place the robot at the start by hand).
const bool RETURN_TO_START = false;

// ================= NEW (Phase 1): solving =================
// Tank turn in SOLVE is capped below 360 degrees (360 = failed trial).
const unsigned long TANK_SOLVE_MAX_MS = 3000;
// A junction seen before this fraction of the expected edge is treated as a
// false junction (robot keeps going straight if it can).
const float FALSE_JUNCTION_FRAC = 0.5f;
// A junction closer than this to the previous node, with the straight line
// continuing, is ignored (wobble). Real junctions on the track are further apart.
const float MIN_NODE_SPACING_CM = 12.0f;

// ================= NEW (Phase 1): BLE / telemetry =================
const long BLE_BAUD = 9600;                      // must match the HM-10
const unsigned long CMD_IDLE_MS = 40;            // command ends after 40 ms silence (no newline)
const unsigned long STATUS_PERIOD_MS = 500;      // CURRENT_STATUS while running
const unsigned long IDLE_STATUS_PERIOD_MS = 3000;
const unsigned long DIAG_PERIOD_MS = 1000;       // DIAG line while running
const bool BLE_DIAG = true;
const bool NAV_ECHO = true;                      // send nav state changes (low priority)

// ================= EEPROM =================
const int EE_RUN_FLAG_ADDR = 0;
const uint8_t RUN_FLAG = 0xA5;
const int EE_TRIM_ADDR = 8;          // 'T', left %, right %
const int EE_MAP_ADDR = 16;

// DRIVE_TEST[:ms]: open-loop straight drive on plain floor (no line needed).
// Used to balance the motor trims and to calibrate ODO_UNITS_PER_CM: the
// odometry counts during the drive and the result is reported at the end.
const unsigned long DRIVE_TEST_MS = 2000;     // default duration
const unsigned long DRIVE_TEST_MAX_MS = 10000;


// #####################################################################
//  maze_types.h
// #####################################################################
// =====================================================================
//  maze_types.h  -  Observation passed from the navigation layer to the
//                   exploration / path-execution logic at every node.
// =====================================================================

enum ObsKind : uint8_t {
  OBS_JUNCTION = 0,   // junction or corner (robot passed through and classified it)
  OBS_DEADEND  = 1,   // line ended (confirmed)
  OBS_CIRCLE   = 2    // black circle (start or end zone)
};

struct NodeObs {
  int32_t x, y;       // estimated node centre (odometry units)
  uint8_t heading;    // absolute heading on arrival (N/E/S/W)
  uint8_t exitMask;   // absolute directions with a line, INCLUDING the one we came from
  uint8_t kind;       // ObsKind
};

enum StepResult : uint8_t {
  STEP_GO = 0,        // outDir is valid: leave the node in that absolute direction
  STEP_DONE = 1,      // finished (exploration complete / goal reached)
  STEP_FAIL = 2       // unrecoverable (map full, no end, route broken)
};


// #####################################################################
//  maze_map.h
// #####################################################################
// =====================================================================
//  maze_map.h  -  Graph representation of the maze + shortest path
//
//  Node   = any place where the robot must decide or stops: junction,
//           corner, dead end, start circle, end circle.
//  Edge   = straight line segment between two nodes. Because the track has
//           only 90-degree turns, every edge leaves a node in exactly one
//           absolute direction (N/E/S/W) and arrives from the opposite one.
//  nbr[d] = what is in absolute direction d from this node:
//             NO_EXIT     no line in that direction
//             UNEXPLORED  a line exists but has not been driven yet (frontier)
//             0..N-1      id of the node at the other end of that edge
//
//  Pure C++ (no Arduino calls) so it can be unit-tested on a PC.
// =====================================================================

#define MAX_NODES   60
#define NO_EXIT     0xFF
#define UNEXPLORED  0xFE
#define NO_NODE     0xFF

// Node flags
#define NF_START    0x01
#define NF_END      0x02
#define NF_DEADEND  0x04

// Absolute directions
#define DIR_N 0
#define DIR_E 1
#define DIR_S 2
#define DIR_W 3

struct MazeNode {
  int16_t  x, y;       // estimated position of the node centre (odometry units)
  uint8_t  nbr[4];     // NO_EXIT / UNEXPLORED / node id, indexed by N,E,S,W
  uint16_t len[4];     // measured edge length (odometry units), 0 = unknown
  uint8_t  flags;      // NF_*
};

struct MazeMap {
  uint8_t  count;
  uint8_t  startNode;
  uint8_t  endNode;
  uint8_t  startHeading;   // direction the robot leaves the start circle
  MazeNode node[MAX_NODES];
};

extern MazeMap gMap;
extern const int8_t DIR_DX[4];
extern const int8_t DIR_DY[4];
extern const char   DIR_CHARS[5];    // "NESW"

// Implemented by the application (mission.cpp on the robot, the test on a PC)
void mazeLog(const char* msg);

// --- direction helpers (defined in the maze_map section) ---
uint8_t dirLeft(uint8_t h);
uint8_t dirRight(uint8_t h);
uint8_t dirBack(uint8_t h);
uint8_t dirBit(uint8_t d);

// Relative action to go from heading h to absolute direction d: 'S','R','U','L'
char    relFromAbs(uint8_t h, uint8_t d);
uint8_t absFromRel(uint8_t h, char rel);

// --- map building ---
void     mapClear();
uint8_t  mapAddNode(int32_t x, int32_t y, uint8_t exitMask, uint8_t flags);
void     mapLink(uint8_t a, uint8_t dirFromA, uint8_t b, uint8_t dirFromB, uint16_t len);
uint8_t  mapExitMask(uint8_t id);
bool     mapHasFrontier(uint8_t id);
uint8_t  mapFrontierCount();
uint8_t  mapDirTo(uint8_t a, uint8_t b);     // direction from a to neighbour b, NO_EXIT if not linked
bool     mapValidate();                       // consistency check (both ends of every edge agree)

// --- shortest path (Dijkstra; BFS when USE_EDGE_LENGTHS == false) ---
// Writes node ids src..dst into out[]; returns number of nodes (0 = no path).
uint8_t  mapShortestPath(uint8_t src, uint8_t dst, uint8_t* out, uint8_t maxLen, uint16_t* costCm);
// Nearest node (by path cost) that still has an UNEXPLORED exit.
// firstDir = direction to leave src on that path (NO_EXIT if src itself is the frontier).
uint8_t  mapNearestFrontier(uint8_t src, uint8_t* firstDir);


// #####################################################################
//  motors.h
// #####################################################################
// =====================================================================
//  motors.h  -  L298N motor control (Phase 0 functions, unchanged logic)
// =====================================================================

extern int currentLeftSpeed;    // last commanded speed (before trim), -255..255
extern int currentRightSpeed;
extern uint8_t gTrimLeftPct;     // motor trim in percent (100 = no change)
extern uint8_t gTrimRightPct;

void motorsInit();
void driveLeft(int speed);
void driveRight(int speed);
void setSpeeds(int leftSpd, int rightSpd);
void halt();
void brakeMotors();
void spinAt(int dir, int spd);   // dir +1 = "L" turn (Phase 0 convention), -1 = "R"


// #####################################################################
//  sensors.h
// #####################################################################
// =====================================================================
//  sensors.h  -  5-channel digital IR line sensor (Phase 0 logic)
//  Index 0..4 = SENSOR_PINS order. Index 0 is the "L" side in the
//  Phase 0 convention (spinAt(+1) turns toward it).
// =====================================================================

extern bool sensorStates[5];
extern float previousError;     // last line offset (-2..+2), kept when line is lost

void sensorsInit();
void pollSensors();
float getLineOffset();
void sensorString(char* out);   // "01100" + '\0' (needs 6 bytes)

bool centerOnLine();
bool anyCenter();
bool outerLeft();
bool outerRight();
bool leftMark();
bool rightMark();
bool leadingInner(int dir);
bool trailingInner(int dir);
bool allSensorsWhite();
bool allSensorsBlack();


// #####################################################################
//  odometry.h
// #####################################################################
// =====================================================================
//  odometry.h  -  Pose estimate without encoders
//
//  Position: integrates the average commanded wheel PWM over time along the
//            current heading (edges are straight, heading is exact).
//  Heading:  discrete N/E/S/W, updated by the navigation layer on every
//            90/180-degree turn.
//  Rotation: integrates (L-R)/2 PWM over time. Only used to work out which
//            line a tank-turn recovery ended on. Self-calibrates on clean turns.
// =====================================================================

struct Pose {
  int32_t x, y;        // odometry units (see ODO_SCALE / ODO_UNITS_PER_CM)
  uint8_t heading;     // 0=N 1=E 2=S 3=W
};

extern Pose gPose;

void    odoReset(int32_t x, int32_t y, uint8_t heading);
void    odoUpdate(bool countRotation);   // call every loop while moving
void    odoShift(int32_t dx, int32_t dy); // apply a correction (node snap)
int32_t odoDistance();                    // total along-track distance (units)

void    odoBeginManeuver();              // zero the rotation accumulator
int32_t odoManeuverRot();                // PWM*ms, + = "L" direction
void    odoCalibrateTurn(int32_t rot, uint8_t quarters);
float   odoRotToQuarters(int32_t rot);   // + = "L" quarter turns
int32_t odoRotPer90();


// #####################################################################
//  nav.h
// #####################################################################
// =====================================================================
//  nav.h  -  Navigation layer (low-level motion FSM)
//
//  This is the Phase 0 state machine (follow / junction pass / turns /
//  recovery / end-zone check), changed so that it no longer decides where
//  to go. At every node it builds a NodeObs and asks the mission layer:
//     missionOnJunction(obs) / missionOnDeadEnd(obs) / missionOnCircle(obs)
//  which answer with a relative action: 'S','L','R','U' or 'X' (stop).
// =====================================================================

enum NavState : uint8_t {
  NAV_IDLE,
  NAV_START,
  NAV_FOLLOW,
  NAV_LOST_HOLD,
  NAV_JUNCTION_PASS,
  NAV_TURN_ALIGN,
  NAV_TURN_CLEAR,
  NAV_TURN_ACQUIRE,
  NAV_TURN_FINE,
  NAV_TURN_BRAKE,
  NAV_REALIGN,
  NAV_DEADEND_CHECK,
  NAV_DEADEND_SWEEP,
  NAV_UTURN,
  NAV_SEARCH,
  NAV_TANK_TURN,
  NAV_END_CHECK,
  NAV_CIRCLE_EXIT,
  NAV_DONE,
  NAV_FAILED,
  NAV_STATE_COUNT
};

void        navInit();
void        navStart(bool insideCircleFacingIn, bool solveMode);
void        navStop();
void        navUpdate();              // call every loop while active
bool        navActive();
NavState    navState();
const char* navStateName();
const char* navFailReason();


// #####################################################################
//  explorer.h
// #####################################################################
// =====================================================================
//  explorer.h  -  Training-phase exploration (frontier-based DFS)
//
//  Called once per node event. Registers/matches the node in the graph,
//  then chooses where to go:
//    1. an unexplored exit of this node (preference S, L, R), else
//    2. the first hop of the shortest known route to the nearest node
//       that still has an unexplored exit (Dijkstra over the graph), else
//    3. DONE (everything reachable is mapped).
//  This is complete on any connected maze, including loops, and does not
//  depend on a left/right-hand rule.
// =====================================================================

void       expBegin(int32_t x0, int32_t y0, uint8_t heading0);
StepResult expOnNode(const NodeObs& o, uint8_t* outDir, int32_t* nodeX, int32_t* nodeY);

void       expSetBudgetExpired(bool expired);   // stop as soon as the end is known
void       expExitChanged(uint8_t newDir);       // tank turn landed on a different exit
void       expHeadingFix(uint8_t heading);       // turn aborted: robot kept this heading

uint8_t    expCurrentNode();
bool       expEndFound();


// #####################################################################
//  path_exec.h
// #####################################################################
// =====================================================================
//  path_exec.h  -  Execute a stored route node by node (SOLVE phase and
//                  optional return-to-start)
//
//  The route is a list of node ids. At every node event the executor:
//    - checks the observed exits against the map (detects false or missed
//      junctions using exits + odometry),
//    - advances to the next node, snaps the pose to the stored position,
//    - returns the absolute direction toward the following node.
// =====================================================================

void       execBegin(const uint8_t* nodes, uint8_t n);
StepResult execOnNode(const NodeObs& o, uint8_t* outDir, int32_t* nodeX, int32_t* nodeY, bool* snap);
StepResult execExitChanged(uint8_t newDir);     // re-plan after a tank-turn landed elsewhere

uint8_t        execStep();          // index of the current node in the route
uint8_t        execTotal();         // number of nodes in the route
uint8_t        execCurrentNode();
const uint8_t* execRoute();


// #####################################################################
//  mission.h
// #####################################################################
// =====================================================================
//  mission.h  -  Mission layer (top-level FSM)
//
//   READY --START_TRAIN--> TRAINING --done--> (RETURNING) --> READY
//   READY --START_SOLVE--> SOLVING  --goal--> COMPLETED
//   any running --STOP--> STOPPED ;  any --RESET--> READY
//   failures --> ERROR (map/path kept if usable)
//
//  The navigation layer calls the missionOn*() hooks at every node.
// =====================================================================

enum MissionState : uint8_t {
  M_READY,
  M_TRAINING,
  M_RETURNING,
  M_SOLVING,
  M_COMPLETED,
  M_STOPPED,
  M_ERROR,
  M_STATE_COUNT
};

void         missionInit(bool resetDuringRun);
void         missionUpdate();                  // call every loop
void         missionCommand(const char* cmd);  // from ble_link (BLE or USB)
void         missionOnLink(bool connected);
MissionState missionState();
bool         missionPathValid();

// Hooks called by nav.cpp. Return relative action 'S','L','R','U' or 'X' = stop.
char missionOnJunction(const NodeObs& o);
char missionOnDeadEnd(const NodeObs& o);
char missionOnCircle(const NodeObs& o);
void missionOnExitChanged(uint8_t newDir);
void missionOnTurnCancelled(uint8_t heading);
void missionOnNavFailed(const char* reason);


// #####################################################################
//  ble_link.h
// #####################################################################
// =====================================================================
//  ble_link.h  -  HM-10 BLE link (Serial1) + USB Serial, line protocol
//
//  Framing: ASCII lines terminated by '\n' (PC may also omit it: a command
//  ends after CMD_IDLE_MS of silence, like Phase 0 with LightBlue).
//  TX never blocks: lines go into a queue and are pumped out as space in
//  the UART buffer allows. Critical lines (results, errors) are kept;
//  telemetry is dropped first when the link is busy.
// =====================================================================

void     linkInit();
void     linkService();                         // RX parse + TX pump, every loop
bool     linkSend(const char* line, bool critical);
uint8_t  linkFreeSlots();
bool     linkConnected();
uint16_t linkDropped();


// #####################################################################
//  storage.h
// #####################################################################
// =====================================================================
//  storage.h  -  EEPROM persistence of the maze map (non-blocking save)
//
//  An EEPROM byte write takes ~3.3 ms, so a ~1 KB map would block the loop
//  for ~3.5 s if written in one go. Instead one byte is written per loop
//  when the EEPROM is ready. The header is written last, so a reset during
//  the save leaves the old map invalid rather than corrupted-but-valid.
// =====================================================================

bool storageLoadMap();          // load into gMap at boot; true if valid
void storageSaveMap();          // start background save of gMap
void storageErase();            // invalidate the stored map
void storageAbort();            // cancel a save in progress
void storageService();          // call every loop
bool storageBusy();

void storageSetRunFlag(bool on);
bool storageRunFlag();


// Command reader used by the BLE/USB parser
struct CmdReader {
  char buf[33];
  uint8_t len;
  unsigned long lastByteMs;
  bool fromBle;
};

// #####################################################################
//  motors.cpp
// #####################################################################
// =====================================================================
//  motors.cpp  -  L298N motor control
//  Copied from Phase 0. Only change: split into its own module.
// =====================================================================

int currentLeftSpeed = 0;
int currentRightSpeed = 0;

// Runtime motor trims (percent). Loaded from EEPROM at boot, set by TRIM_L / TRIM_R.
uint8_t gTrimLeftPct = (uint8_t)(TRIM_LEFT * 100 + 0.5f);
uint8_t gTrimRightPct = (uint8_t)(TRIM_RIGHT * 100 + 0.5f);

void motorsInit() {
  pinMode(MOTOR_L_PWM, OUTPUT);
  pinMode(MOTOR_L_IN1, OUTPUT);
  pinMode(MOTOR_L_IN2, OUTPUT);
  pinMode(MOTOR_R_PWM, OUTPUT);
  pinMode(MOTOR_R_IN3, OUTPUT);
  pinMode(MOTOR_R_IN4, OUTPUT);
  halt();
}

void driveLeft(int speed) {
  speed = (int)((long)speed * gTrimLeftPct / 100);
  speed = constrain(speed, -MOTOR_LIMIT, MOTOR_LIMIT);
  if (INVERT_L) speed = -speed;

  if (speed >= 0) {
    digitalWrite(MOTOR_L_IN1, HIGH);
    digitalWrite(MOTOR_L_IN2, LOW);
  } else {
    digitalWrite(MOTOR_L_IN1, LOW);
    digitalWrite(MOTOR_L_IN2, HIGH);
  }
  analogWrite(MOTOR_L_PWM, abs(speed));
}

void driveRight(int speed) {
  speed = (int)((long)speed * gTrimRightPct / 100);
  speed = constrain(speed, -MOTOR_LIMIT, MOTOR_LIMIT);
  if (INVERT_R) speed = -speed;

  if (speed >= 0) {
    digitalWrite(MOTOR_R_IN3, HIGH);
    digitalWrite(MOTOR_R_IN4, LOW);
  } else {
    digitalWrite(MOTOR_R_IN3, LOW);
    digitalWrite(MOTOR_R_IN4, HIGH);
  }
  analogWrite(MOTOR_R_PWM, abs(speed));
}

void setSpeeds(int leftSpd, int rightSpd) {
  currentLeftSpeed = leftSpd;
  currentRightSpeed = rightSpd;
  driveLeft(leftSpd);
  driveRight(rightSpd);
}

void halt() {
  setSpeeds(0, 0);
}

void brakeMotors() {
  currentLeftSpeed = 0;
  currentRightSpeed = 0;
  digitalWrite(MOTOR_L_IN1, LOW);
  digitalWrite(MOTOR_L_IN2, LOW);
  digitalWrite(MOTOR_R_IN3, LOW);
  digitalWrite(MOTOR_R_IN4, LOW);
  analogWrite(MOTOR_L_PWM, 255);
  analogWrite(MOTOR_R_PWM, 255);
}

void spinAt(int dir, int spd) {
  setSpeeds(dir * spd, -dir * spd);
}


// #####################################################################
//  sensors.cpp
// #####################################################################
// =====================================================================
//  sensors.cpp  -  Sensor reading and predicates (copied from Phase 0)
// =====================================================================

bool sensorStates[5] = {false};
float previousError = 0.0f;

void sensorsInit() {
  for (int i = 0; i < 5; i++) pinMode(SENSOR_PINS[i], INPUT);
}

void pollSensors() {
  for (int i = 0; i < 5; i++) {
    int raw = digitalRead(SENSOR_PINS[i]);
    sensorStates[i] = (LINE_IS_BLACK ? (raw == LOW) : (raw == HIGH));
  }
}

void sensorString(char* out) {
  for (int i = 0; i < 5; i++) out[i] = sensorStates[i] ? '1' : '0';
  out[5] = '\0';
}

float getLineOffset() {
  float weightedPos = 0.0f;
  int activeSensors = 0;
  const float positions[5] = {-2.0f, -1.0f, 0.0f, 1.0f, 2.0f};

  for (int i = 0; i < 5; i++) {
    if (sensorStates[i]) {
      weightedPos += positions[i];
      activeSensors++;
    }
  }
  if (activeSensors == 0) return previousError;
  return weightedPos / activeSensors;
}

bool centerOnLine()  { return sensorStates[2]; }
bool anyCenter()     { return sensorStates[1] || sensorStates[2] || sensorStates[3]; }
bool outerLeft()     { return sensorStates[0]; }
bool outerRight()    { return sensorStates[4]; }
bool leftMark()      { return sensorStates[0] && sensorStates[1] && sensorStates[2]; }
bool rightMark()     { return sensorStates[2] && sensorStates[3] && sensorStates[4]; }
bool leadingInner(int dir)  { return (dir > 0) ? sensorStates[1] : sensorStates[3]; }
bool trailingInner(int dir) { return (dir > 0) ? sensorStates[3] : sensorStates[1]; }

bool allSensorsWhite() {
  for (int i = 0; i < 5; i++) if (sensorStates[i]) return false;
  return true;
}

bool allSensorsBlack() {
  for (int i = 0; i < 5; i++) if (!sensorStates[i]) return false;
  return true;
}


// #####################################################################
//  maze_map.cpp
// #####################################################################
// =====================================================================
//  maze_map.cpp  -  Graph storage and Dijkstra/BFS shortest path
// =====================================================================

MazeMap gMap;
const int8_t DIR_DX[4] = {0, 1, 0, -1};   // N E S W
const int8_t DIR_DY[4] = {1, 0, -1, 0};
const char   DIR_CHARS[5] = "NESW";

// Direction helpers (left/right in the Phase 0 "L"/"R" convention)
uint8_t dirLeft(uint8_t h)  { return (uint8_t)((h + 3) & 3); }
uint8_t dirRight(uint8_t h) { return (uint8_t)((h + 1) & 3); }
uint8_t dirBack(uint8_t h)  { return (uint8_t)((h + 2) & 3); }
uint8_t dirBit(uint8_t d)   { return (uint8_t)(1u << d); }

// Scratch arrays for Dijkstra (static: keeps them off the AVR stack)
static uint16_t sDist[MAX_NODES];
static uint8_t  sPrev[MAX_NODES];
static uint8_t  sDone[MAX_NODES];

char relFromAbs(uint8_t h, uint8_t d) {
  switch ((d - h) & 3) {
    case 0:  return 'S';
    case 1:  return 'R';
    case 2:  return 'U';
    default: return 'L';
  }
}

uint8_t absFromRel(uint8_t h, char rel) {
  switch (rel) {
    case 'S': return h;
    case 'R': return dirRight(h);
    case 'U': return dirBack(h);
    case 'L': return dirLeft(h);
  }
  return NO_EXIT;
}

static int16_t clamp16(int32_t v) {
  if (v > 32000) return 32000;
  if (v < -32000) return -32000;
  return (int16_t)v;
}

void mapClear() {
  memset(&gMap, 0, sizeof(gMap));
  gMap.startNode = NO_NODE;
  gMap.endNode = NO_NODE;
  gMap.startHeading = START_HEADING;
}

uint8_t mapAddNode(int32_t x, int32_t y, uint8_t exitMask, uint8_t flags) {
  if (gMap.count >= MAX_NODES) return NO_NODE;
  uint8_t id = gMap.count++;
  MazeNode& n = gMap.node[id];
  n.x = clamp16(x);
  n.y = clamp16(y);
  for (uint8_t d = 0; d < 4; d++) {
    n.nbr[d] = (exitMask & dirBit(d)) ? UNEXPLORED : NO_EXIT;
    n.len[d] = 0;
  }
  n.flags = flags;
  return id;
}

void mapLink(uint8_t a, uint8_t da, uint8_t b, uint8_t db, uint16_t len) {
  gMap.node[a].nbr[da] = b;
  gMap.node[a].len[da] = len;
  gMap.node[b].nbr[db] = a;
  gMap.node[b].len[db] = len;
}

uint8_t mapExitMask(uint8_t id) {
  uint8_t m = 0;
  for (uint8_t d = 0; d < 4; d++)
    if (gMap.node[id].nbr[d] != NO_EXIT) m |= dirBit(d);
  return m;
}

bool mapHasFrontier(uint8_t id) {
  for (uint8_t d = 0; d < 4; d++)
    if (gMap.node[id].nbr[d] == UNEXPLORED) return true;
  return false;
}

uint8_t mapFrontierCount() {
  uint8_t c = 0;
  for (uint8_t i = 0; i < gMap.count; i++)
    for (uint8_t d = 0; d < 4; d++)
      if (gMap.node[i].nbr[d] == UNEXPLORED) c++;
  return c;
}

uint8_t mapDirTo(uint8_t a, uint8_t b) {
  if (a >= gMap.count) return NO_EXIT;
  for (uint8_t d = 0; d < 4; d++)
    if (gMap.node[a].nbr[d] == b) return d;
  return NO_EXIT;
}

bool mapValidate() {
  for (uint8_t i = 0; i < gMap.count; i++) {
    for (uint8_t d = 0; d < 4; d++) {
      uint8_t j = gMap.node[i].nbr[d];
      if (j < MAX_NODES) {
        if (j >= gMap.count) return false;
        if (gMap.node[j].nbr[dirBack(d)] != i) return false;
      }
    }
  }
  return true;
}

// Edge cost in cm-like units. BFS = every edge costs 1.
static uint16_t edgeCost(uint8_t a, uint8_t d) {
  if (!USE_EDGE_LENGTHS) return 1;
  uint32_t cm = (uint32_t)(gMap.node[a].len[d] / ODO_UNITS_PER_CM);
  return (uint16_t)(cm + NODE_COST_CM);
}

// Single-source Dijkstra over explored edges only. O(N^2), N <= 60: < 1 ms.
static void dijkstra(uint8_t src) {
  for (uint8_t i = 0; i < gMap.count; i++) {
    sDist[i] = 0xFFFF;
    sPrev[i] = NO_NODE;
    sDone[i] = 0;
  }
  sDist[src] = 0;

  for (;;) {
    uint8_t u = NO_NODE;
    uint16_t best = 0xFFFF;
    for (uint8_t i = 0; i < gMap.count; i++) {
      if (!sDone[i] && sDist[i] < best) { best = sDist[i]; u = i; }
    }
    if (u == NO_NODE) break;
    sDone[u] = 1;

    for (uint8_t d = 0; d < 4; d++) {
      uint8_t v = gMap.node[u].nbr[d];
      if (v >= MAX_NODES || v >= gMap.count) continue;   // NO_EXIT / UNEXPLORED
      uint32_t nd = (uint32_t)sDist[u] + edgeCost(u, d);
      if (nd < sDist[v]) {
        sDist[v] = (nd > 0xFFFE) ? 0xFFFE : (uint16_t)nd;
        sPrev[v] = u;
      }
    }
  }
}

uint8_t mapShortestPath(uint8_t src, uint8_t dst, uint8_t* out, uint8_t maxLen, uint16_t* costCm) {
  if (src >= gMap.count || dst >= gMap.count) return 0;
  dijkstra(src);
  if (sDist[dst] == 0xFFFF) return 0;

  // Walk back from dst, then reverse
  uint8_t n = 0;
  for (uint8_t v = dst; v != NO_NODE; v = sPrev[v]) {
    if (n >= maxLen) return 0;
    out[n++] = v;
    if (v == src) break;
  }
  for (uint8_t i = 0; i < n / 2; i++) {
    uint8_t t = out[i]; out[i] = out[n - 1 - i]; out[n - 1 - i] = t;
  }
  if (costCm) *costCm = sDist[dst];
  return n;
}

uint8_t mapNearestFrontier(uint8_t src, uint8_t* firstDir) {
  *firstDir = NO_EXIT;
  if (src >= gMap.count) return NO_NODE;
  if (mapHasFrontier(src)) return src;

  dijkstra(src);
  uint8_t best = NO_NODE;
  uint16_t bestD = 0xFFFF;
  for (uint8_t i = 0; i < gMap.count; i++) {
    if (sDist[i] < bestD && mapHasFrontier(i)) { bestD = sDist[i]; best = i; }
  }
  if (best == NO_NODE) return NO_NODE;

  // Find the first hop out of src
  uint8_t v = best;
  while (sPrev[v] != src && sPrev[v] != NO_NODE) v = sPrev[v];
  *firstDir = mapDirTo(src, v);
  return best;
}


// #####################################################################
//  odometry.cpp
// #####################################################################
// =====================================================================
//  odometry.cpp
// =====================================================================

Pose gPose = {0, 0, START_HEADING};

static unsigned long sLastMs = 0;
static int32_t sTransAcc = 0;     // remainder in PWM*ms*2
static int32_t sDistTotal = 0;
static int32_t sRot = 0;          // PWM*ms
static int32_t sRotPer90 = ROT_PER_90_DEFAULT;

void odoReset(int32_t x, int32_t y, uint8_t heading) {
  gPose.x = x;
  gPose.y = y;
  gPose.heading = heading & 3;
  sLastMs = millis();
  sTransAcc = 0;
  sDistTotal = 0;
  sRot = 0;
}

void odoUpdate(bool countRotation) {
  unsigned long now = millis();
  unsigned long dt = now - sLastMs;
  sLastMs = now;
  if (dt == 0) return;
  if (dt > 50) dt = 50;            // ignore long gaps (e.g. after a pause)

  // Translation: (L+R)/2 * dt, kept as 2x to avoid losing the half
  sTransAcc += (int32_t)(currentLeftSpeed + currentRightSpeed) * (int32_t)dt;
  int32_t units = sTransAcc / (2 * ODO_SCALE);
  if (units != 0) {
    sTransAcc -= units * 2 * ODO_SCALE;
    gPose.x += units * DIR_DX[gPose.heading];
    gPose.y += units * DIR_DY[gPose.heading];
    sDistTotal += (units > 0) ? units : -units;
  }

  if (countRotation) {
    sRot += (int32_t)(currentLeftSpeed - currentRightSpeed) / 2 * (int32_t)dt;
  }
}

void    odoShift(int32_t dx, int32_t dy) { gPose.x += dx; gPose.y += dy; }
int32_t odoDistance() { return sDistTotal; }

void    odoBeginManeuver() { sRot = 0; }
int32_t odoManeuverRot()   { return sRot; }
int32_t odoRotPer90()      { return sRotPer90; }

void odoCalibrateTurn(int32_t rot, uint8_t quarters) {
  if (quarters == 0) return;
  int32_t sample = (rot < 0 ? -rot : rot) / quarters;
  // Reject wild samples (stalls, kicks), then exponential moving average
  if (sample < sRotPer90 / 2 || sample > sRotPer90 * 2) return;
  sRotPer90 = (sRotPer90 * 3 + sample) / 4;
}

float odoRotToQuarters(int32_t rot) {
  return (float)rot / (float)sRotPer90;
}


// #####################################################################
//  explorer.cpp
// #####################################################################
// =====================================================================
//  explorer.cpp  -  Frontier-based exploration with loop closure
//
//  Loop closure without encoders:
//  The robot only ever drives straight between nodes, and its heading is
//  exact (90-degree steps). So when it leaves node A in direction d over an
//  unexplored edge and reaches a node after travelling `len` units, the
//  candidate "already known" node B must satisfy:
//    - B lies on the ray from A in direction d (small perpendicular error)
//    - the distance A->B along d is close to the measured `len`
//      (tolerance grows with the distance driven since B was last visited)
//    - B has exactly the same set of exits as observed
//    - B's exit facing back toward A is still UNEXPLORED
//  If a candidate passes all four tests it is the same node (loop closed);
//  otherwise a new node is created. Pose is snapped to the stored node
//  position on every known-node arrival, so drift does not accumulate.
// =====================================================================

static uint8_t  sCur = NO_NODE;          // node we are at / just left
static uint8_t  sTravelFrom = NO_NODE;   // node the current edge started at
static uint8_t  sTravelDir = NO_EXIT;    // absolute direction we left it in
static uint8_t  sTravelDest = NO_NODE;   // known destination (NO_NODE if unexplored edge)
static uint32_t sOdo = 0;                // total distance driven in training (units)
static uint32_t sLastVisit[MAX_NODES];   // sOdo when each node was last visited
static bool     sBudgetExpired = false;

static char exLog[64];

static int32_t iabs32(int32_t v) { return v < 0 ? -v : v; }

void expBegin(int32_t x0, int32_t y0, uint8_t heading0) {
  mapClear();
  gMap.startHeading = heading0;
  uint8_t s = mapAddNode(x0, y0, dirBit(heading0), NF_START);
  gMap.startNode = s;
  sCur = s;
  sTravelFrom = s;
  sTravelDir = heading0;
  sTravelDest = NO_NODE;
  sOdo = 0;
  sLastVisit[s] = 0;
  sBudgetExpired = false;
  mazeLog("EXP_BEGIN");
}

uint8_t expCurrentNode() { return sCur; }
bool    expEndFound()    { return gMap.endNode != NO_NODE; }
void    expSetBudgetExpired(bool e) { sBudgetExpired = e; }

void expExitChanged(uint8_t newDir) {
  // A tank-turn recovery put us on a different exit of sCur than planned.
  sTravelFrom = sCur;
  sTravelDir = newDir;
  uint8_t n = gMap.node[sCur].nbr[newDir];
  if (n == NO_EXIT) {                         // exit was not detected: add it
    gMap.node[sCur].nbr[newDir] = UNEXPLORED;
    n = UNEXPLORED;
  }
  sTravelDest = (n < MAX_NODES) ? n : NO_NODE;
  snprintf(exLog, sizeof(exLog), "EXIT_CHANGED,%u,%c", sCur, DIR_CHARS[newDir]);
  mazeLog(exLog);
}

void expHeadingFix(uint8_t heading) {
  if (heading != sTravelDir) expExitChanged(heading);
}

// Find an existing node that matches an observation reached over an unexplored edge.
// Odometry drift between the robot and a stored node grows with the distance
// driven since the robot was last AT that node, so the tolerance is per node.
static uint8_t findMatch(const NodeObs& o, uint8_t from, uint8_t dir, int32_t len) {
  const MazeNode& A = gMap.node[from];
  const uint8_t arrival = dirBack(dir);
  const uint8_t obsMask = o.exitMask | dirBit(arrival);

  uint8_t best = NO_NODE;
  float bestScore = 1e9f;

  for (uint8_t i = 0; i < gMap.count; i++) {
    if (i == from) continue;
    const MazeNode& B = gMap.node[i];

    // Topology tests first: same exits, circle-ness, and the line facing A unexplored
    bool isCircle = (B.flags & (NF_START | NF_END)) != 0;
    if ((o.kind == OBS_CIRCLE) != isCircle) continue;
    if (mapExitMask(i) != obsMask) continue;
    if (B.nbr[arrival] != UNEXPLORED) continue;

    // Geometry: B must lie ahead of A on the ray, at about the measured distance
    float drift = TOL_DRIFT_FRAC * (float)(sOdo - sLastVisit[i]);
    float tolPerp  = TOL_PERP_CM  * ODO_UNITS_PER_CM + drift;
    float tolAlong = TOL_ALONG_CM * ODO_UNITS_PER_CM + TOL_ALONG_FRAC * (float)len + drift;

    int32_t dx = (int32_t)B.x - A.x;
    int32_t dy = (int32_t)B.y - A.y;
    int32_t along = dx * DIR_DX[dir] + dy * DIR_DY[dir];
    int32_t perp  = (DIR_DX[dir] != 0) ? iabs32(dy) : iabs32(dx);
    if (along <= 0) continue;
    float ePerp = (float)perp / tolPerp;
    float eAlong = (float)iabs32(along - len) / tolAlong;
    if (ePerp > 1.0f || eAlong > 1.0f) continue;

    float score = ePerp + eAlong;
    if (score < bestScore) { bestScore = score; best = i; }
  }
  return best;
}

static uint8_t chooseExit(uint8_t node, uint8_t h, StepResult* res) {
  const MazeNode& n = gMap.node[node];
  *res = STEP_GO;

  if (sBudgetExpired && expEndFound()) { *res = STEP_DONE; return NO_EXIT; }

  // 1. unexplored exit here (straight first: no turn = fastest and safest)
  static const char pref[4] = {'S', 'L', 'R', 'U'};
  for (uint8_t k = 0; k < 4; k++) {
    uint8_t d = absFromRel(h, pref[k]);
    if (n.nbr[d] == UNEXPLORED) return d;
  }

  // 2. route to nearest frontier
  uint8_t fd;
  uint8_t f = mapNearestFrontier(node, &fd);
  if (f != NO_NODE && fd != NO_EXIT) return fd;

  // 3. nothing left
  *res = expEndFound() ? STEP_DONE : STEP_FAIL;
  if (*res == STEP_FAIL) mazeLog("EXP_FAIL,NO_END_FOUND");
  return NO_EXIT;
}

StepResult expOnNode(const NodeObs& o, uint8_t* outDir, int32_t* nodeX, int32_t* nodeY) {
  const uint8_t h = o.heading;
  const uint8_t arrival = dirBack(h);

  // Edges are straight, so the arrival heading must equal the departure direction.
  if (h != sTravelDir) expHeadingFix(h);

  const MazeNode& F = gMap.node[sTravelFrom];
  int32_t len = ((int32_t)o.x - F.x) * DIR_DX[h] + ((int32_t)o.y - F.y) * DIR_DY[h];

  // False junction filter: too close to the last node and the line continues
  // straight -> PD wobble, not a branch. Keep driving straight, record nothing.
  if (o.kind == OBS_JUNCTION && (o.exitMask & dirBit(h)) &&
      (float)len < MIN_NODE_SPACING_CM * ODO_UNITS_PER_CM) {
    snprintf(exLog, sizeof(exLog), "IGNORED_SHORT_JUNCTION,%ld", (long)len);
    mazeLog(exLog);
    *nodeX = o.x;
    *nodeY = o.y;
    *outDir = h;
    return STEP_GO;
  }

  if (len < 1) len = 1;
  if (len > 65000) len = 65000;

  uint8_t node = NO_NODE;
  sOdo += (uint32_t)len;

  if (sTravelDest != NO_NODE) {
    // ---- known edge: we know exactly where we are ----
    node = sTravelDest;
    uint8_t expMask = mapExitMask(node);
    uint8_t obsMask = o.exitMask | dirBit(arrival);
    if (expMask != obsMask) {
      snprintf(exLog, sizeof(exLog), "WARN_MISMATCH,%u,exp=%u,obs=%u", node, expMask, obsMask);
      mazeLog(exLog);
    }
  } else {
    // ---- unexplored edge: loop closure or new node ----
    node = findMatch(o, sTravelFrom, h, len);
    if (node != NO_NODE) {
      mapLink(sTravelFrom, h, node, arrival, (uint16_t)len);
      snprintf(exLog, sizeof(exLog), "LOOP_CLOSED,%u,%u", sTravelFrom, node);
      mazeLog(exLog);
    } else {
      if (gMap.count >= MAX_NODES) {
        mazeLog("MAP_FULL");
        return expEndFound() ? STEP_DONE : STEP_FAIL;
      }
      uint8_t flags = 0;
      uint8_t mask = o.exitMask | dirBit(arrival);
      if (o.kind == OBS_DEADEND) { flags = NF_DEADEND; mask = dirBit(arrival); }
      if (o.kind == OBS_CIRCLE)  { flags = NF_END;     mask = dirBit(arrival); }

      node = mapAddNode(o.x, o.y, mask, flags);
      mapLink(sTravelFrom, h, node, arrival, (uint16_t)len);

      if (flags & NF_END) {
        gMap.endNode = node;
        snprintf(exLog, sizeof(exLog), "END_FOUND,%u", node);
        mazeLog(exLog);
      }
      snprintf(exLog, sizeof(exLog), "NODE_NEW,%u,%d,%d,%u,%u",
               node, gMap.node[node].x, gMap.node[node].y, mask, flags);
      mazeLog(exLog);
    }
  }

  sCur = node;
  sLastVisit[node] = sOdo;
  *nodeX = gMap.node[node].x;
  *nodeY = gMap.node[node].y;

  StepResult res;
  uint8_t d = chooseExit(node, h, &res);
  if (res != STEP_GO) return res;

  sTravelFrom = node;
  sTravelDir = d;
  uint8_t nb = gMap.node[node].nbr[d];
  sTravelDest = (nb < MAX_NODES) ? nb : NO_NODE;
  *outDir = d;
  return STEP_GO;
}


// #####################################################################
//  path_exec.cpp
// #####################################################################
// =====================================================================
//  path_exec.cpp  -  Route execution with junction-count error checking
// =====================================================================

static uint8_t peRoute[MAX_NODES];
static uint8_t peLen = 0;
static uint8_t peIdx = 0;
static char    peLog[64];

static bool isCircleNode(uint8_t id) {
  return (gMap.node[id].flags & (NF_START | NF_END)) != 0;
}

void execBegin(const uint8_t* nodes, uint8_t n) {
  if (n > MAX_NODES) n = MAX_NODES;
  memcpy(peRoute, nodes, n);
  peLen = n;
  peIdx = 0;
}

uint8_t        execStep()        { return peIdx; }
uint8_t        execTotal()       { return peLen; }
uint8_t        execCurrentNode() { return (peLen > 0) ? peRoute[peIdx] : NO_NODE; }
const uint8_t* execRoute()       { return peRoute; }

StepResult execOnNode(const NodeObs& o, uint8_t* outDir, int32_t* nodeX, int32_t* nodeY, bool* snap) {
  *snap = false;
  if (peLen < 2 || peIdx + 1 >= peLen) return STEP_DONE;

  const uint8_t h = o.heading;
  const uint8_t cur = peRoute[peIdx];
  const uint8_t exp = peRoute[peIdx + 1];
  const uint8_t goal = peRoute[peLen - 1];

  // ---------- black circle ----------
  if (o.kind == OBS_CIRCLE) {
    if (isCircleNode(goal)) {
      if (exp != goal) mazeLog("WARN_EARLY_GOAL");
      peIdx = peLen - 1;
      *nodeX = gMap.node[goal].x;
      *nodeY = gMap.node[goal].y;
      *snap = true;
      return STEP_DONE;
    }
    mazeLog("ERR_UNEXPECTED_CIRCLE");
    return STEP_FAIL;
  }

  // ---------- next node is a circle: junction marks at its edge are ignored ----------
  if (isCircleNode(exp)) {
    if (o.kind == OBS_JUNCTION && (o.exitMask & dirBit(h))) {
      *outDir = h;
      return STEP_GO;
    }
    mazeLog("ERR_BLOCKED_BEFORE_GOAL");
    return STEP_FAIL;
  }

  const uint8_t obsMask = (o.kind == OBS_DEADEND) ? dirBit(dirBack(h))
                                                 : (uint8_t)(o.exitMask | dirBit(dirBack(h)));
  const MazeNode& C = gMap.node[cur];
  int32_t travelled = ((int32_t)o.x - C.x) * DIR_DX[h] + ((int32_t)o.y - C.y) * DIR_DY[h];
  uint8_t dCurExp = mapDirTo(cur, exp);
  uint16_t edgeLen = (dCurExp != NO_EXIT) ? C.len[dCurExp] : 0;

  // Too close to the last node with the line continuing: wobble, ignore it
  if (o.kind == OBS_JUNCTION && (o.exitMask & dirBit(h)) &&
      (float)travelled < MIN_NODE_SPACING_CM * ODO_UNITS_PER_CM) {
    snprintf(peLog, sizeof(peLog), "IGNORED_SHORT_JUNCTION,%ld", (long)travelled);
    mazeLog(peLog);
    *outDir = h;
    return STEP_GO;
  }

  if (mapExitMask(exp) != obsMask) {
    // (a) false junction: far too early, and straight is available -> keep going
    if (o.kind == OBS_JUNCTION && (o.exitMask & dirBit(h)) &&
        (float)travelled < FALSE_JUNCTION_FRAC * (float)edgeLen) {
      snprintf(peLog, sizeof(peLog), "FALSE_JUNCTION,%ld/%u", (long)travelled, edgeLen);
      mazeLog(peLog);
      *outDir = h;
      return STEP_GO;
    }
    // (b) we drove straight through `exp` without detecting it -> this is the node after it
    if (peIdx + 2 < peLen) {
      uint8_t n2 = peRoute[peIdx + 2];
      if (!isCircleNode(n2) && mapExitMask(n2) == obsMask &&
          mapDirTo(exp, n2) == h && dCurExp == h) {
        snprintf(peLog, sizeof(peLog), "RESYNC_SKIPPED,%u", exp);
        mazeLog(peLog);
        peIdx++;
      } else {
        snprintf(peLog, sizeof(peLog), "WARN_MISMATCH,%u,exp=%u,obs=%u", exp, mapExitMask(exp), obsMask);
        mazeLog(peLog);
      }
    }
  }

  if (o.kind == OBS_DEADEND) {
    mazeLog("ERR_DEADEND_IN_ROUTE");
    return STEP_FAIL;
  }

  peIdx++;
  const uint8_t node = peRoute[peIdx];
  *nodeX = gMap.node[node].x;
  *nodeY = gMap.node[node].y;
  *snap = true;

  if (peIdx + 1 >= peLen) return STEP_DONE;

  uint8_t d = mapDirTo(node, peRoute[peIdx + 1]);
  if (d == NO_EXIT) {
    mazeLog("ERR_ROUTE_BROKEN");
    return STEP_FAIL;
  }
  *outDir = d;
  return STEP_GO;
}

StepResult execExitChanged(uint8_t newDir) {
  const uint8_t cur = peRoute[peIdx];
  const uint8_t goal = peRoute[peLen - 1];
  const uint8_t nb = gMap.node[cur].nbr[newDir];
  if (nb >= MAX_NODES) {
    mazeLog("ERR_REPLAN_UNKNOWN_EDGE");
    return STEP_FAIL;
  }

  static uint8_t tmp[MAX_NODES];
  uint16_t cost;
  uint8_t n = mapShortestPath(nb, goal, tmp + 1, MAX_NODES - 1, &cost);
  if (n == 0) {
    mazeLog("ERR_REPLAN_NO_PATH");
    return STEP_FAIL;
  }
  tmp[0] = cur;
  execBegin(tmp, (uint8_t)(n + 1));
  snprintf(peLog, sizeof(peLog), "REPLANNED,%u,%c,len=%u", cur, DIR_CHARS[newDir], (unsigned)(n + 1));
  mazeLog(peLog);
  return STEP_GO;
}


// #####################################################################
//  storage.cpp
// #####################################################################
// =====================================================================
//  storage.cpp
//  Layout at EE_MAP_ADDR:
//    +0 'M'  +1 'Z'  +2 version  +3 checksum lo  +4 checksum hi
//    +5 ...  first (4 + count * sizeof(MazeNode)) bytes of gMap
// =====================================================================

#define MAP_VERSION 1
#define HDR_SIZE 5
#define MAP_HEAD_BYTES 4          // count, startNode, endNode, startHeading

static uint8_t  stPhase = 0;       // 0 idle, 1 invalidate, 2 body, 3 checksum+magic
static uint16_t stIdx = 0;
static uint16_t stLen = 0;
static uint16_t stSum = 0;

static uint16_t mapBytes() {
  return MAP_HEAD_BYTES + (uint16_t)gMap.count * sizeof(MazeNode);
}

// Fletcher-16 checksum
static uint16_t checksum(const uint8_t* p, uint16_t n) {
  uint16_t a = 0, b = 0;
  for (uint16_t i = 0; i < n; i++) {
    a = (a + p[i]) % 255;
    b = (b + a) % 255;
  }
  return (uint16_t)((b << 8) | a);
}

bool storageLoadMap() {
  if (EEPROM.read(EE_MAP_ADDR) != 'M' || EEPROM.read(EE_MAP_ADDR + 1) != 'Z' ||
      EEPROM.read(EE_MAP_ADDR + 2) != MAP_VERSION) {
    mapClear();
    return false;
  }
  uint16_t stored = EEPROM.read(EE_MAP_ADDR + 3) | ((uint16_t)EEPROM.read(EE_MAP_ADDR + 4) << 8);
  uint8_t count = EEPROM.read(EE_MAP_ADDR + HDR_SIZE);
  if (count == 0 || count > MAX_NODES) { mapClear(); return false; }

  uint8_t* p = (uint8_t*)&gMap;
  uint16_t n = MAP_HEAD_BYTES + (uint16_t)count * sizeof(MazeNode);
  for (uint16_t i = 0; i < n; i++) p[i] = EEPROM.read(EE_MAP_ADDR + HDR_SIZE + i);

  if (checksum(p, n) != stored || !mapValidate()) {
    mapClear();
    return false;
  }
  return true;
}

void storageSaveMap() {
  stLen = mapBytes();
  stSum = checksum((const uint8_t*)&gMap, stLen);
  stIdx = 0;
  stPhase = 1;
}

void storageAbort() { stPhase = 0; }
bool storageBusy()  { return stPhase != 0; }

void storageErase() {
  stPhase = 0;
  EEPROM.update(EE_MAP_ADDR, 0);
}

void storageService() {
  if (stPhase == 0 || !eeprom_is_ready()) return;

  const uint8_t* p = (const uint8_t*)&gMap;
  switch (stPhase) {
    case 1:
      EEPROM.update(EE_MAP_ADDR, 0);       // invalidate first
      stPhase = 2;
      break;
    case 2:
      EEPROM.update(EE_MAP_ADDR + HDR_SIZE + stIdx, p[stIdx]);
      if (++stIdx >= stLen) { stIdx = 0; stPhase = 3; }
      break;
    case 3: {
      const uint8_t hdr[5] = {'M', 'Z', MAP_VERSION, (uint8_t)(stSum & 0xFF), (uint8_t)(stSum >> 8)};
      // write bytes 4,3,2,1 then 0 last ('M' makes it valid)
      uint8_t i = (uint8_t)(4 - stIdx);
      EEPROM.update(EE_MAP_ADDR + i, hdr[i]);
      if (++stIdx >= 5) stPhase = 0;
      break;
    }
  }
}

void storageSetRunFlag(bool on) { EEPROM.update(EE_RUN_FLAG_ADDR, on ? RUN_FLAG : 0); }
bool storageRunFlag()           { return EEPROM.read(EE_RUN_FLAG_ADDR) == RUN_FLAG; }


// #####################################################################
//  ble_link.cpp
// #####################################################################
// =====================================================================
//  ble_link.cpp
// =====================================================================

#define TXQ_SLOTS 8
#define TXQ_LEN   80
#define TELEMETRY_MAX_QUEUED 3


static CmdReader usbCmd = {{0}, 0, 0, false};
static CmdReader bleCmd = {{0}, 0, 0, true};

static char     txq[TXQ_SLOTS][TXQ_LEN];
static uint8_t  txHead = 0, txTail = 0, txCount = 0;
static uint8_t  txOff = 0;            // bytes of txq[txTail] already written
static uint16_t txDropped = 0;
static bool     connected = false;

void linkInit() {
  Serial1.begin(BLE_BAUD);
}

bool     linkConnected() { return connected; }
uint16_t linkDropped()   { return txDropped; }
uint8_t  linkFreeSlots() { return TXQ_SLOTS - txCount; }

bool linkSend(const char* line, bool critical) {
  // USB mirror (only if it fits, so it never blocks)
  size_t n = strlen(line);
  if ((size_t)Serial.availableForWrite() > n + 1) Serial.println(line);

  if (!critical && txCount >= TELEMETRY_MAX_QUEUED) return false;
  if (txCount >= TXQ_SLOTS) { txDropped++; return false; }

  strncpy(txq[txHead], line, TXQ_LEN - 2);
  txq[txHead][TXQ_LEN - 2] = '\0';
  size_t l = strlen(txq[txHead]);
  txq[txHead][l] = '\n';
  txq[txHead][l + 1] = '\0';
  txHead = (txHead + 1) % TXQ_SLOTS;
  txCount++;
  return true;
}

static void pumpTx() {
  while (txCount > 0) {
    int space = Serial1.availableForWrite();
    if (space <= 0) return;
    const char* s = txq[txTail] + txOff;
    size_t rem = strlen(s);
    size_t n = ((size_t)space < rem) ? (size_t)space : rem;
    Serial1.write((const uint8_t*)s, n);
    txOff += n;
    if (n < rem) return;              // UART buffer full, continue next loop
    txOff = 0;
    txTail = (txTail + 1) % TXQ_SLOTS;
    txCount--;
  }
}

static void handleLine(CmdReader& r) {
  r.buf[r.len] = '\0';
  r.len = 0;
  char* cmd = r.buf;

  for (char* p = cmd; *p; p++) if (*p >= 'a' && *p <= 'z') *p = *p - 'a' + 'A';
  if (strlen(cmd) < 2) return;

  // HM-10 status messages (need AT+NOTI1): OK+CONN / OK+LOST
  if (strncmp(cmd, "OK+", 3) == 0 || strncmp(cmd, "OK", 2) == 0) {
    if (strstr(cmd, "CONN")) { connected = true;  missionOnLink(true); }
    if (strstr(cmd, "LOST")) { connected = false; missionOnLink(false); }
    return;
  }

  if (r.fromBle && !connected) {      // data arrived, so a central is connected
    connected = true;
    missionOnLink(true);
  }
  missionCommand(cmd);
}

static void readPort(Stream& port, CmdReader& r) {
  while (port.available()) {
    char c = (char)port.read();
    r.lastByteMs = millis();
    if (c == '\n' || c == '\r') {
      if (r.len > 0) handleLine(r);
    } else if ((isAlphaNumeric(c) || c == '_' || c == '+' || c == ':' || c == ',') &&
               r.len < sizeof(r.buf) - 1) {
      r.buf[r.len++] = c;               // anything else (noise) is dropped
    }
  }
  if (r.len > 0 && millis() - r.lastByteMs >= CMD_IDLE_MS) handleLine(r);
}

void linkService() {
  readPort(Serial, usbCmd);
  readPort(Serial1, bleCmd);
  pumpTx();
}


// #####################################################################
//  nav.cpp
// #####################################################################
// =====================================================================
//  nav.cpp  -  Navigation layer: Phase 0 motion FSM, made map-aware
//
//  Kept from Phase 0 (same logic, same constants):
//    PD line following, junction lockout, junction pass, end-zone check,
//    turn align/clear/acquire/fine/brake, realign, lost-hold, search,
//    dead-end check, U-turn, tank turn.
//
//  Changed for Phase 1:
//    - No left-hand rule. Every junction is fully classified (L/S/R) and
//      the mission layer chooses the action. (Phase 0 "fast-path left"
//      removed: it hid straight exits and corrupted the map.)
//    - Odometry runs every loop; junction centre is estimated at detection.
//    - Heading is updated on every turn; after a tank-turn recovery the new
//      heading is snapped to the nearest real exit of that node.
//    - Turn engine can pass over N lines (U-turn at a junction).
//    - All-white must last WHITE_CONFIRM_MS; dead end needs a sweep.
//    - New CIRCLE_EXIT state to U-turn out of a black circle.
//    - Tank turn capped below 360 degrees in SOLVE (360 = failed trial).
// =====================================================================

static const char* const NAV_NAMES[NAV_STATE_COUNT] = {
  "IDLE", "START", "FOLLOW", "LOST_HOLD", "JUNCTION_PASS",
  "TURN_ALIGN", "TURN_CLEAR", "TURN_ACQUIRE", "TURN_FINE", "TURN_BRAKE",
  "REALIGN", "DEADEND_CHECK", "DEADEND_SWEEP", "UTURN", "SEARCH",
  "TANK_TURN", "END_CHECK", "CIRCLE_EXIT", "DONE", "FAILED"
};

static NavState state = NAV_IDLE;
static unsigned long stateStart = 0;
static bool sSolveMode = false;
static const char* sFailReason = "";

// PD state
static float lastScaledErr = 0.0f;
static unsigned long lastControlMs = 0;
static bool pdInit = true;

// Junction lockout
static bool isLockedJunction = false;
static unsigned long lockStartTime = 0;
static unsigned long clearStartTime = 0;
static bool isClearTimerActive = false;

// Debounce counters
static uint8_t whiteReads = 0;
static uint8_t clearReads = 0;
static uint8_t leaveReads = 0;
static uint8_t endWhiteReads = 0;
static bool whiteActive = false;
static unsigned long whiteStart = 0;
static int32_t whiteX = 0, whiteY = 0;

// Junction data
static bool seenLeft = false;
static bool seenRight = false;
static bool allBlackActive = false;
static unsigned long allBlackStart = 0;
static unsigned long detectTime = 0;
static int32_t jDetX = 0, jDetY = 0;
static bool junctionCandidateActive = false;
static unsigned long junctionCandidateStart = 0;

// Turning
static int turnDir = 1;
static long alignMs = 0;
static unsigned long lastTurnEnd = 0;
static bool turnHappened = false;
static int realignDir = 1;
static unsigned long spinStart = 0;
static int lostDir = 1;
static bool uturnActive = false;
static bool uturnSawOff = false;
static bool keepSpinStart = false;

// Maneuver bookkeeping (Phase 1)
static uint8_t turnSkip = 0;         // lines to pass over before stopping
static uint8_t turnQuarters = 1;     // 1 = 90 deg, 2 = 180 deg (for calibration)
static uint8_t mvStartHeading = 0;   // heading before the maneuver
static uint8_t mvTarget = 0;         // intended absolute exit
static uint8_t mvMask = 0;           // real exits at this node (tank recovery)
static bool    mvTank = false;
static int32_t mvRotBeforeTank = 0;

// Search
static int searchSide = 1;
static uint8_t searchStep = 0;
static bool searchFlipped = false;
static unsigned long stepStart = 0;

// Tank turn
static int tankDir = 1;
static uint8_t tankStep = 0;
static unsigned long tankStepStart = 0;

// Dead-end sweep / circle exit
static uint8_t sweepPhase = 0;
static uint8_t circlePhase = 0;
static bool circleClearActive = false;
static unsigned long circleClearStart = 0;

// ================= HELPERS =================

static void navEvent(const char* msg) {
  char buf[64];
  snprintf(buf, sizeof(buf), "EVT:%s", msg);
  linkSend(buf, false);
}

static void setState(NavState s) {
  state = s;
  stateStart = millis();

  if (s == NAV_FOLLOW) {
    junctionCandidateActive = false;
    whiteReads = 0;
    whiteActive = false;
    pdInit = true;
  }
  if ((s == NAV_TURN_CLEAR && !keepSpinStart) || s == NAV_UTURN || s == NAV_REALIGN) {
    spinStart = millis();
  }
  keepSpinStart = false;

  if (NAV_ECHO) {
    char buf[32];
    snprintf(buf, sizeof(buf), "NAV:%s", NAV_NAMES[s]);
    linkSend(buf, false);
  }
}

static unsigned long elapsed() { return millis() - stateStart; }

static int kickSpeed(int spd) {
  return (millis() - spinStart < TURN_KICK_MS) ? SPEED_KICK : spd;
}

static void spin(int dir) { spinAt(dir, kickSpeed(SPEED_TURN)); }

static void lockJunction() {
  isLockedJunction = true;
  lockStartTime = millis();
  isClearTimerActive = false;
}

static void processJunctionLock() {
  if (!isLockedJunction) return;
  if (millis() - lockStartTime < LOCKOUT_JUNCTION) return;

  if (!outerLeft() && !outerRight()) {
    if (!isClearTimerActive) {
      clearStartTime = millis();
      isClearTimerActive = true;
    }
    if (millis() - clearStartTime >= CONFIRM_CLEAR) {
      isLockedJunction = false;
      isClearTimerActive = false;
    }
  } else {
    isClearTimerActive = false;
  }
}

static void navFinish() {
  halt();
  setState(NAV_DONE);
}

static void navFail(const char* reason) {
  halt();
  sFailReason = reason;
  setState(NAV_FAILED);
  missionOnNavFailed(reason);
}

// ================= PD CONTROLLER (Phase 0) =================

static void runPD() {
  if (sensorStates[2] && !sensorStates[0] && !sensorStates[1] &&
      !sensorStates[3] && !sensorStates[4]) {
    previousError = 0.0f;
    lastScaledErr = 0.0f;
    pdInit = true;
    lastControlMs = millis();
    setSpeeds(SPEED_BASE, SPEED_BASE);
    return;
  }

  float err = getLineOffset();
  previousError = err;

  unsigned long now = millis();
  if (!pdInit && (now - lastControlMs < CONTROL_MS)) return;

  float scaled = (err < 0) ? err * LEFT_BIAS : err;
  float dErr = 0.0f;
  if (pdInit) pdInit = false;
  else dErr = scaled - lastScaledErr;

  lastScaledErr = scaled;
  lastControlMs = now;

  int correction = (int)(KP_GAIN * scaled + KD_GAIN * dErr);
  int lDrive = constrain(SPEED_BASE - correction, SPEED_MIN, SPEED_MAX);
  int rDrive = constrain(SPEED_BASE + correction, SPEED_MIN, SPEED_MAX);
  setSpeeds(lDrive, rDrive);
}

// ================= MANEUVER BOOKKEEPING =================

// Called when the robot starts rotating at a node: heading becomes the target.
static void beginRotation() {
  odoBeginManeuver();
  mvTank = false;
  gPose.heading = mvTarget;
}

// After a tank turn found a line, work out which exit it is on.
static void resolveHeadingAfterTank() {
  float q = odoRotToQuarters(mvRotBeforeTank) +
            (float)tankDir * (float)(millis() - stateStart) * 4.0f / (float)TANK_360_MS;

  uint8_t best = mvTarget;
  float bestErr = 99.0f;
  for (uint8_t c = 0; c < 4; c++) {
    if (!(mvMask & dirBit(c))) continue;
    int k = (mvStartHeading - c) & 3;            // "L" quarter turns needed to face c
    float d = q - (float)k;
    while (d > 2.0f) d -= 4.0f;
    while (d < -2.0f) d += 4.0f;
    if (fabs(d) < bestErr) { bestErr = fabs(d); best = c; }
  }

  gPose.heading = best;
  char buf[40];
  snprintf(buf, sizeof(buf), "TANK_HEADING,%c,q=%d", DIR_CHARS[best], (int)(q * 10));
  navEvent(buf);
  if (best != mvTarget) missionOnExitChanged(best);
}

// ================= STATE ENTRY ACTIONS =================

static void startJunctionPass(bool keepData) {
  if (!keepData) {
    seenLeft = false;
    seenRight = false;
    detectTime = millis();
    jDetX = gPose.x;
    jDetY = gPose.y;
  }
  allBlackActive = false;
  clearReads = 0;
  setSpeeds(SPEED_BASE, SPEED_BASE);
  setState(NAV_JUNCTION_PASS);
}

static void startAlign(int dir, long ms) {
  turnDir = dir;
  alignMs = ms;
  setState(NAV_TURN_ALIGN);
}

static void startLostHold() {
  navEvent("LINE_LOST");
  lostDir = (previousError < 0) ? 1 : -1;
  setState(NAV_LOST_HOLD);
}

static void startDeadEndCheck() {
  navEvent("POSSIBLE_DEAD_END");
  setState(NAV_DEADEND_CHECK);
}

// 180-degree turn on the line we came from (dead end or after circle exit)
static void startUTurn() {
  mvStartHeading = gPose.heading;
  mvTarget = dirBack(gPose.heading);
  mvMask = dirBit(mvTarget);
  turnQuarters = 2;
  turnSkip = 0;
  beginRotation();

  uturnSawOff = !centerOnLine();
  turnDir = -1;
  uturnActive = true;
  setState(NAV_UTURN);
}

static void startBrake() {
  if (!mvTank) odoCalibrateTurn(odoManeuverRot(), turnQuarters);
  uturnActive = false;
  previousError = getLineOffset();
  lockJunction();
  brakeMotors();
  setState(NAV_TURN_BRAKE);
}

// Line found during a turn: stop here, or pass over it (U-turn at a junction)
static void lineAcquired() {
  if (turnSkip > 0) {
    turnSkip--;
    keepSpinStart = true;
    setState(NAV_TURN_CLEAR);
    return;
  }
  startBrake();
}

static void startRealign() {
  realignDir = (previousError < 0) ? 1 : -1;
  setState(NAV_REALIGN);
}

static void startTankTurn(int dir) {
  navEvent("TANK_TURN");
  mvRotBeforeTank = odoManeuverRot();
  mvTank = true;
  uturnActive = false;
  tankDir = dir;
  tankStep = 0;
  tankStepStart = millis();
  setState(NAV_TANK_TURN);
}

static void startSearch() {
  navEvent("SEARCHING");
  uturnActive = false;
  searchSide = (previousError < 0) ? 1 : -1;
  searchStep = 0;
  searchFlipped = false;
  stepStart = millis();
  setState(NAV_SEARCH);
}

static void startEndCheck() {
  navEvent("ALL_BLACK_CHECK");
  endWhiteReads = 0;
  setSpeeds(SPEED_END_CHECK, SPEED_END_CHECK);
  setState(NAV_END_CHECK);
}

static void startCircleExit() {
  circlePhase = 0;
  circleClearActive = false;
  setState(NAV_CIRCLE_EXIT);
}

// ================= NODE EVENTS -> MISSION LAYER =================

static void deadEndConfirmed() {
  halt();
  NodeObs o;
  o.heading = gPose.heading;
  o.x = whiteX + (int32_t)DIR_DX[o.heading] * ALIGN_UNITS;
  o.y = whiteY + (int32_t)DIR_DY[o.heading] * ALIGN_UNITS;
  o.exitMask = dirBit(dirBack(o.heading));
  o.kind = OBS_DEADEND;

  char a = missionOnDeadEnd(o);
  if (a == 'X') { navFinish(); return; }
  startUTurn();
}

static void circleReached() {
  halt();
  NodeObs o;
  o.heading = gPose.heading;
  o.x = gPose.x;
  o.y = gPose.y;
  o.exitMask = dirBit(dirBack(o.heading));
  o.kind = OBS_CIRCLE;

  char a = missionOnCircle(o);
  if (a == 'U') { startCircleExit(); return; }
  if (a == 'S') { lockJunction(); setState(NAV_FOLLOW); return; }   // map says "not a circle"
  navFinish();
}

static void decideAfterPass() {
  bool L = seenLeft;
  bool S = anyCenter();
  bool R = seenRight;
  const uint8_t h = gPose.heading;

  long crawl = (long)(millis() - detectTime);
  long align = (long)TURN_ALIGN_MS - crawl;           // negative = reverse
  if (align < -ALIGN_BACK_MAX_MS) align = -ALIGN_BACK_MAX_MS;

  char dbg[48];
  snprintf(dbg, sizeof(dbg), "JUNCTION,L=%d,S=%d,R=%d,crawl=%ld", L, S, R, crawl);
  navEvent(dbg);

  if (!L && !S && !R) {
    // Marks seen but nothing continues: behave like a dead end
    whiteX = jDetX;
    whiteY = jDetY;
    deadEndConfirmed();
    return;
  }

  NodeObs o;
  o.heading = h;
  o.x = jDetX + (int32_t)DIR_DX[h] * ALIGN_UNITS;
  o.y = jDetY + (int32_t)DIR_DY[h] * ALIGN_UNITS;
  o.exitMask = dirBit(dirBack(h));
  if (S) o.exitMask |= dirBit(h);
  if (L) o.exitMask |= dirBit(dirLeft(h));
  if (R) o.exitMask |= dirBit(dirRight(h));
  o.kind = OBS_JUNCTION;

  char a = missionOnJunction(o);   // may snap gPose

  mvStartHeading = h;
  mvMask = o.exitMask;
  turnSkip = 0;
  turnQuarters = 1;

  switch (a) {
    case 'S':
      lockJunction();
      setState(NAV_FOLLOW);
      break;
    case 'L':
      mvTarget = dirLeft(h);
      startAlign(1, align);
      break;
    case 'R':
      mvTarget = dirRight(h);
      startAlign(-1, align);
      break;
    case 'U':
      // Spin toward the side with no branch so the first line found is the
      // one we came from; if both sides have branches, pass over one.
      mvTarget = dirBack(h);
      turnQuarters = 2;
      if (!L)      { startAlign(1, align); }
      else if (!R) { startAlign(-1, align); }
      else         { turnSkip = 1; startAlign(1, align); }
      break;
    default:
      navFinish();
      break;
  }
}

// ================= STATE HANDLERS =================

static void runStart() {
  if (allSensorsBlack()) {
    leaveReads = 0;
    setSpeeds(SPEED_BASE, SPEED_BASE);
    return;
  }
  if (++leaveReads >= CONFIRM_READS) {
    lockJunction();
    setState(NAV_FOLLOW);
  }
}

static void runFollow() {
  processJunctionLock();

  if (allSensorsWhite()) {
    if (!whiteActive) {
      whiteActive = true;
      whiteStart = millis();
      whiteX = gPose.x;
      whiteY = gPose.y;
    }
    if (++whiteReads >= CONFIRM_READS && millis() - whiteStart >= WHITE_CONFIRM_MS) {
      if (turnHappened && (millis() - lastTurnEnd < POST_TURN_GRACE_MS)) {
        startRealign();
      } else if (fabs(previousError) <= DEADEND_ERR_MAX) {
        startDeadEndCheck();
      } else {
        startLostHold();
      }
    }
    return;
  }
  whiteReads = 0;
  whiteActive = false;

  bool junctionDetected = leftMark() || rightMark();
  if (!isLockedJunction && junctionDetected) {
    if (!junctionCandidateActive) {
      junctionCandidateActive = true;
      junctionCandidateStart = millis();
    }
    unsigned long need = (fabs(previousError) >= JUNCTION_OFFCENTER_ERR)
                         ? JUNCTION_CONFIRM_OFFCENTER_MS : JUNCTION_CONFIRM_MS;
    if (millis() - junctionCandidateStart >= need) {
      junctionCandidateActive = false;
      startJunctionPass(false);
      return;
    }
  } else {
    junctionCandidateActive = false;
  }

  runPD();
}

static void runLostHold() {
  if (!allSensorsWhite()) {
    navEvent("LINE_FOUND");
    setState(NAV_FOLLOW);
    return;
  }
  if (elapsed() >= LOST_HOLD_MS) {
    startSearch();
    return;
  }
  if (lostDir > 0) setSpeeds(SPEED_LOST_OUTER, SPEED_LOST_INNER);
  else             setSpeeds(SPEED_LOST_INNER, SPEED_LOST_OUTER);
}

static void runDeadEndCheck() {
  if (!allSensorsWhite()) {
    navEvent("DEAD_END_CANCELLED");
    setState(NAV_FOLLOW);
    return;
  }
  if (elapsed() >= DEADEND_CHECK_MS) {
    if (DEADEND_SWEEP_ENABLE) {
      sweepPhase = 0;
      setState(NAV_DEADEND_SWEEP);
    } else {
      deadEndConfirmed();
    }
    return;
  }
  setSpeeds(SPEED_BASE, SPEED_BASE);
}

// Sweep: +1 side, then -1 side (double), then back to centre.
static void runDeadEndSweep() {
  if (anyCenter()) {
    halt();
    navEvent("DEAD_END_CANCELLED_SWEEP");
    setState(NAV_FOLLOW);
    return;
  }
  unsigned long dur = (sweepPhase == 1) ? 2 * DEADEND_SWEEP_MS : DEADEND_SWEEP_MS;
  if (elapsed() >= dur) {
    sweepPhase++;
    stateStart = millis();
    if (sweepPhase >= 3) {
      deadEndConfirmed();
      return;
    }
  }
  spinAt((sweepPhase == 1) ? -1 : 1, SPEED_TURN_FINE);
}

static void runJunctionPass() {
  if (outerLeft()) seenLeft = true;
  if (outerRight()) seenRight = true;

  if (allSensorsBlack()) {
    if (!allBlackActive) {
      allBlackActive = true;
      allBlackStart = millis();
    } else if (millis() - allBlackStart >= END_ZONE_MS) {
      startEndCheck();
      return;
    }
  } else {
    allBlackActive = false;
  }

  if (!outerLeft() && !outerRight()) {
    if (++clearReads >= CONFIRM_READS) {
      decideAfterPass();
      return;
    }
  } else {
    clearReads = 0;
  }

  if (!allBlackActive && elapsed() >= JUNCTION_PASS_TIMEOUT) {
    navEvent("JUNCTION_PASS_TIMEOUT");
    decideAfterPass();
    return;
  }
  setSpeeds(SPEED_BASE, SPEED_BASE);
}

static void runEndCheck() {
  if (!allSensorsBlack()) {
    if (++endWhiteReads >= CONFIRM_READS) {
      navEvent("NOT_END_ZONE");
      startJunctionPass(true);
      return;
    }
  } else {
    endWhiteReads = 0;
  }
  if (elapsed() >= END_CHECK_MS) {
    circleReached();
    return;
  }
  setSpeeds(SPEED_END_CHECK, SPEED_END_CHECK);
}

static void runTurnAlign() {
  if (alignMs > 0 && allSensorsBlack()) {
    // Decision was made, but this is a black zone: cancel the turn
    turnSkip = 0;
    missionOnTurnCancelled(gPose.heading);
    startJunctionPass(true);
    return;
  }

  unsigned long target = (alignMs >= 0) ? (unsigned long)alignMs : (unsigned long)(-alignMs);
  if (elapsed() < target) {
    if (alignMs >= 0) setSpeeds(SPEED_BASE, SPEED_BASE);
    else              setSpeeds(-SPEED_BASE, -SPEED_BASE);
    return;
  }

  beginRotation();
  setState(NAV_TURN_CLEAR);
}

static void runTurnClear() {
  if (!centerOnLine()) {
    setState(NAV_TURN_ACQUIRE);
    return;
  }
  if (elapsed() >= TIMEOUT_CLEAR) {
    startTankTurn(turnDir);
    return;
  }
  spin(turnDir);
}

static void runTurnAcquire() {
  if (millis() - spinStart >= TURN_MIN_MS) {
    if (centerOnLine()) { lineAcquired(); return; }
    if (leadingInner(turnDir)) { setState(NAV_TURN_FINE); return; }
  }
  if (elapsed() >= TIMEOUT_TURN) {
    startTankTurn(turnDir);
    return;
  }
  spin(turnDir);
}

static void runTurnFine() {
  if (centerOnLine() || trailingInner(turnDir)) {
    lineAcquired();
    return;
  }
  if (!allSensorsWhite()) previousError = getLineOffset();

  if (elapsed() >= TURN_FINE_TIMEOUT) {
    lastTurnEnd = millis();
    turnHappened = true;
    uturnActive = false;
    turnSkip = 0;
    if (allSensorsWhite()) startRealign();
    else setState(NAV_FOLLOW);
    return;
  }
  spinAt(turnDir, uturnActive ? SPEED_UTURN_FINE : SPEED_TURN_FINE);
}

static void runTurnBrake() {
  if (elapsed() < TURN_BRAKE_MS) {
    brakeMotors();
    return;
  }
  lastTurnEnd = millis();
  turnHappened = true;
  setState(NAV_FOLLOW);
}

static void runRealign() {
  if (anyCenter()) {
    halt();
    lockJunction();
    lastTurnEnd = millis();
    setState(NAV_FOLLOW);
    return;
  }
  if (elapsed() >= REALIGN_TIMEOUT) {
    turnHappened = false;
    startSearch();
    return;
  }
  spinAt(realignDir, kickSpeed(SPEED_REALIGN));
}

static void runUTurn() {
  if (!centerOnLine()) uturnSawOff = true;

  if (elapsed() < UTURN_MIN_TIME) {
    spinAt(turnDir, kickSpeed(SPEED_UTURN));
    return;
  }
  if (uturnSawOff && centerOnLine()) { startBrake(); return; }
  if (uturnSawOff && leadingInner(turnDir)) { setState(NAV_TURN_FINE); return; }

  if (elapsed() >= UTURN_MAX_TIME) {
    startTankTurn(turnDir);
    return;
  }
  spinAt(turnDir, kickSpeed(SPEED_UTURN));
}

static void runTankTurn() {
  if (millis() - stateStart >= TANK_MIN_MS && anyCenter()) {
    navEvent("TANK_LINE_FOUND");
    resolveHeadingAfterTank();
    startBrake();
    return;
  }

  unsigned long limit = sSolveMode ? TANK_SOLVE_MAX_MS : TANK_360_MS;
  if (elapsed() >= limit) {
    navFail("TANK_NO_LINE");
    return;
  }

  if (millis() - tankStepStart >= TANK_STEP_MS) {
    tankStep++;
    tankStepStart = millis();
  }
  int v = (tankStep % 2 == 0) ? -SPEED_TANK_DRIVE : SPEED_TANK_DRIVE;
  setSpeeds(v + tankDir * SPEED_TANK_ROT, v - tankDir * SPEED_TANK_ROT);
}

static void runSearch() {
  if (!allSensorsWhite()) {
    navEvent("LINE_REACQUIRED");
    halt();
    lockJunction();
    turnHappened = false;
    setState(NAV_FOLLOW);
    return;
  }

  unsigned long stepLen = SEARCH_STEP_MS + (searchStep / 2) * SEARCH_STEP_GROW;
  if (millis() - stepStart >= stepLen) {
    searchStep++;
    stepStart = millis();
    if (searchStep >= SEARCH_MAX_STEPS) {
      if (!searchFlipped) {
        searchFlipped = true;
        searchSide = -searchSide;
        searchStep = 0;
      } else {
        navFail("SEARCH_FAILED");
        return;
      }
    }
  }

  bool reverse = (searchStep % 2 == 0);
  int v = reverse ? -SPEED_SEARCH : SPEED_SEARCH;
  setSpeeds(v + searchSide * SEARCH_ARC, v - searchSide * SEARCH_ARC);
}

// Reverse until the sensor bar is out of the disc, a bit more, then U-turn
static void runCircleExit() {
  if (circlePhase == 0) {
    if (!allSensorsBlack()) {
      if (!circleClearActive) {
        circleClearActive = true;
        circleClearStart = millis();
      }
      if (millis() - circleClearStart >= CIRCLE_CLEAR_MS) {
        circlePhase = 1;
        stateStart = millis();
      }
    } else {
      circleClearActive = false;
    }
    if (circlePhase == 0 && elapsed() >= CIRCLE_EXIT_TIMEOUT) {
      navFail("CIRCLE_EXIT_TIMEOUT");
      return;
    }
    setSpeeds(-SPEED_BASE, -SPEED_BASE);
    return;
  }

  if (elapsed() < CIRCLE_EXTRA_MS) {
    setSpeeds(-SPEED_BASE, -SPEED_BASE);
    return;
  }
  halt();
  startUTurn();
}

// ================= PUBLIC API =================

void navInit() {
  state = NAV_IDLE;
  halt();
}

static void resetRunVars() {
  previousError = 0.0f;
  pdInit = true;
  isLockedJunction = false;
  isClearTimerActive = false;
  turnHappened = false;
  uturnActive = false;
  whiteReads = 0;
  whiteActive = false;
  junctionCandidateActive = false;
  leaveReads = 0;
  endWhiteReads = 0;
  turnSkip = 0;
  mvTank = false;
  sFailReason = "";
}

void navStart(bool insideCircleFacingIn, bool solveMode) {
  resetRunVars();
  sSolveMode = solveMode;
  if (insideCircleFacingIn) startCircleExit();
  else setState(NAV_START);
}

void navStop() {
  halt();
  setState(NAV_IDLE);
}

bool navActive() {
  return state != NAV_IDLE && state != NAV_DONE && state != NAV_FAILED;
}

NavState    navState()      { return state; }
const char* navStateName()  { return NAV_NAMES[state]; }
const char* navFailReason() { return sFailReason; }

void navUpdate() {
  if (!navActive()) return;

  odoUpdate(state != NAV_TANK_TURN);

  switch (state) {
    case NAV_START:         runStart();        break;
    case NAV_FOLLOW:        runFollow();       break;
    case NAV_LOST_HOLD:     runLostHold();     break;
    case NAV_JUNCTION_PASS: runJunctionPass(); break;
    case NAV_TURN_ALIGN:    runTurnAlign();    break;
    case NAV_TURN_CLEAR:    runTurnClear();    break;
    case NAV_TURN_ACQUIRE:  runTurnAcquire();  break;
    case NAV_TURN_FINE:     runTurnFine();     break;
    case NAV_TURN_BRAKE:    runTurnBrake();    break;
    case NAV_REALIGN:       runRealign();      break;
    case NAV_DEADEND_CHECK: runDeadEndCheck(); break;
    case NAV_DEADEND_SWEEP: runDeadEndSweep(); break;
    case NAV_UTURN:         runUTurn();        break;
    case NAV_SEARCH:        runSearch();       break;
    case NAV_TANK_TURN:     runTankTurn();     break;
    case NAV_END_CHECK:     runEndCheck();     break;
    case NAV_CIRCLE_EXIT:   runCircleExit();   break;
    default:                halt();            break;
  }
}


// #####################################################################
//  mission.cpp
// #####################################################################
// =====================================================================
//  mission.cpp  -  Top-level FSM, command handling, telemetry, results
// =====================================================================

static const char* const M_NAMES[M_STATE_COUNT] = {
  "READY", "TRAINING", "RETURNING", "SOLVING", "COMPLETED", "STOPPED", "ERROR"
};

static MissionState mState = M_READY;
static unsigned long mStateStart = 0;
static unsigned long sTrainStart = 0;

static bool     sPathValid = false;
static bool     sPathPartial = false;
static uint8_t  sPath[MAX_NODES];
static uint8_t  sPathLen = 0;
static uint16_t sPathCost = 0;
static char     sActions[MAX_NODES + 1];

static bool sAtStartFacingIn = false;   // set after an autonomous return to start
static bool sPendingStop = false;

static unsigned long lastStatusMs = 0;
static unsigned long lastDiagMs = 0;

// Bulk dumps (sent a few lines at a time so the queue never overflows)
static int16_t sMapDump = -1;     // -1 idle, 0 header, 1..count nodes, count+1 end
static int16_t sPathDump = -1;    // -1 idle, 0 header, then chunks
static uint8_t sPathDumpPos = 0;
static uint8_t sPathDumpPart = 0; // 0 actions, 1 nodes

static char tx[80];

// ================= helpers =================

void mazeLog(const char* msg) {
  char buf[72];
  snprintf(buf, sizeof(buf), "EVT:%s", msg);
  linkSend(buf, true);
}

static void setMission(MissionState s) {
  mState = s;
  mStateStart = millis();
  if (s != M_TRAINING && s != M_SOLVING && s != M_RETURNING) storageSetRunFlag(false);
  snprintf(tx, sizeof(tx), "EVT:MISSION,%s", M_NAMES[s]);
  linkSend(tx, true);
}

static bool running() {
  return mState == M_TRAINING || mState == M_SOLVING || mState == M_RETURNING;
}

static void sendError(const char* code) {
  snprintf(tx, sizeof(tx), "ERROR:%s", code);
  linkSend(tx, true);
}

static void sendAck(const char* cmd) {
  snprintf(tx, sizeof(tx), "ACK:%s", cmd);
  linkSend(tx, true);
}

static void sendReady() {
  snprintf(tx, sizeof(tx), "ROBOT_READY:%u,%u,%s", sPathValid ? 1 : 0, gMap.count, M_NAMES[mState]);
  linkSend(tx, true);
}

static uint8_t currentNode() {
  if (mState == M_TRAINING) return expCurrentNode();
  if (mState == M_SOLVING || mState == M_RETURNING) return execCurrentNode();
  return NO_NODE;
}

static void sendStatus(bool critical) {
  uint8_t step = 0, total = 0;
  if (mState == M_SOLVING || mState == M_RETURNING || mState == M_COMPLETED) {
    step = execStep();
    total = execTotal();
  }
  snprintf(tx, sizeof(tx), "CURRENT_STATUS:%s,%s,%u,%c,%u,%u,%u/%u,%ld,%ld,%u",
           M_NAMES[mState], navStateName(), currentNode(), DIR_CHARS[gPose.heading],
           gMap.count, mapFrontierCount(), step, total,
           (long)gPose.x, (long)gPose.y, sPathValid ? 1 : 0);
  linkSend(tx, critical);
}

static void sendDiag() {
  char sens[6];
  sensorString(sens);
  snprintf(tx, sizeof(tx), "DIAG:%s,%d,%d,%d", sens, (int)(previousError * 100),
           currentLeftSpeed, currentRightSpeed);
  linkSend(tx, false);
}

// Shortest path start -> end, plus the per-node action string
static bool computePath(bool partial) {
  sPathValid = false;
  sPathLen = 0;
  sActions[0] = '\0';
  if (gMap.startNode == NO_NODE || gMap.endNode == NO_NODE) return false;

  uint8_t n = mapShortestPath(gMap.startNode, gMap.endNode, sPath, MAX_NODES, &sPathCost);
  if (n < 2) return false;

  // Action at each intermediate node = turn from arrival heading to exit heading
  uint8_t k = 0;
  for (uint8_t i = 1; i + 1 < n; i++) {
    uint8_t hin = mapDirTo(sPath[i - 1], sPath[i]);
    uint8_t hout = mapDirTo(sPath[i], sPath[i + 1]);
    sActions[k++] = relFromAbs(hin, hout);
  }
  sActions[k] = '\0';
  sPathLen = n;
  sPathValid = true;
  sPathPartial = partial;
  return true;
}

static void startDumps(bool map, bool path) {
  if (map) sMapDump = 0;
  if (path && sPathValid) { sPathDump = 0; sPathDumpPos = 0; sPathDumpPart = 0; }
}

static void serviceDumps() {
  while (linkFreeSlots() > 3) {
    if (sPathDump >= 0) {
      if (sPathDump == 0) {
        snprintf(tx, sizeof(tx), "FINAL_PATH:BEGIN,%u,%u,%u,%u",
                 sPathLen, (unsigned)strlen(sActions), sPathCost, sPathPartial ? 1 : 0);
        linkSend(tx, true);
        sPathDump = 1;
      } else if (sPathDumpPart == 0) {
        // actions, 40 per line
        uint8_t len = strlen(sActions);
        if (sPathDumpPos >= len) { sPathDumpPart = 1; sPathDumpPos = 0; continue; }
        char chunk[41];
        uint8_t c = 0;
        while (c < 40 && sPathDumpPos < len) chunk[c++] = sActions[sPathDumpPos++];
        chunk[c] = '\0';
        snprintf(tx, sizeof(tx), "FINAL_PATH:A,%s", chunk);
        linkSend(tx, true);
      } else if (sPathDumpPart == 1) {
        // node ids, 12 per line
        if (sPathDumpPos >= sPathLen) {
          linkSend("FINAL_PATH:END", true);
          sPathDump = -1;
          continue;
        }
        int p = snprintf(tx, sizeof(tx), "FINAL_PATH:N");
        for (uint8_t c = 0; c < 12 && sPathDumpPos < sPathLen; c++)
          p += snprintf(tx + p, sizeof(tx) - p, ",%u", sPath[sPathDumpPos++]);
        linkSend(tx, true);
      }
    } else if (sMapDump >= 0) {
      if (sMapDump == 0) {
        snprintf(tx, sizeof(tx), "MAP:BEGIN,%u,%u,%u,%u,%d",
                 gMap.count, gMap.startNode, gMap.endNode, gMap.startHeading,
                 (int)(ODO_UNITS_PER_CM * 10));
        linkSend(tx, true);
        sMapDump = 1;
      } else if (sMapDump <= gMap.count) {
        const MazeNode& n = gMap.node[sMapDump - 1];
        snprintf(tx, sizeof(tx), "MAP:N,%d,%d,%d,%u,%u,%u,%u,%u",
                 sMapDump - 1, n.x, n.y, n.nbr[0], n.nbr[1], n.nbr[2], n.nbr[3], n.flags);
        linkSend(tx, true);
        sMapDump++;
      } else {
        linkSend("MAP:END", true);
        sMapDump = -1;
      }
    } else {
      return;
    }
  }
}

// ================= phase transitions =================

static void trainingFinished(bool partial) {
  if (computePath(partial)) {
    storageSaveMap();
    snprintf(tx, sizeof(tx), "TRAINING_COMPLETED:%u,%u,%u,%u",
             gMap.count, (unsigned)strlen(sActions), sPathCost, partial ? 1 : 0);
    linkSend(tx, true);
    startDumps(true, true);
  } else {
    sendError("NO_PATH");
    startDumps(true, false);
  }
}

// Exploration step: register node, choose exit, snap pose
static char trainStep(const NodeObs& o) {
  if (millis() - sTrainStart > TRAIN_MAX_MS) expSetBudgetExpired(true);

  uint8_t dir = NO_EXIT;
  int32_t nx = 0, ny = 0;
  StepResult r = expOnNode(o, &dir, &nx, &ny);
  odoShift(nx - o.x, ny - o.y);

  if (r == STEP_GO) return relFromAbs(o.heading, dir);

  if (r == STEP_DONE) {
    trainingFinished(false);
    if (RETURN_TO_START && sPathValid) {
      static uint8_t route[MAX_NODES];
      uint16_t cost;
      uint8_t cur = expCurrentNode();
      uint8_t n = mapShortestPath(cur, gMap.startNode, route, MAX_NODES, &cost);
      if (n >= 2) {
        execBegin(route, n);
        setMission(M_RETURNING);
        linkSend("EVT:RETURN_TO_START", true);
        return relFromAbs(o.heading, mapDirTo(cur, route[1]));
      }
    }
    setMission(M_READY);
    return 'X';
  }

  // STEP_FAIL
  sendError("EXPLORE_FAIL");
  if (expEndFound()) trainingFinished(true);
  setMission(M_ERROR);
  return 'X';
}

// Route step (solve or return-to-start)
static char execStepAction(const NodeObs& o) {
  uint8_t dir = NO_EXIT;
  int32_t nx = 0, ny = 0;
  bool snap;
  StepResult r = execOnNode(o, &dir, &nx, &ny, &snap);
  if (snap) odoShift(nx - o.x, ny - o.y);

  if (r == STEP_GO) return relFromAbs(o.heading, dir);

  if (r == STEP_DONE) {
    if (mState == M_SOLVING) {
      linkSend("SOLVING_COMPLETED", true);
      setMission(M_COMPLETED);
    } else {
      linkSend("EVT:AT_START", true);
      sAtStartFacingIn = true;
      setMission(M_READY);
    }
    return 'X';
  }

  sendError("ROUTE_FAIL");
  setMission(M_ERROR);
  return 'X';
}

// ================= nav hooks =================

char missionOnJunction(const NodeObs& o) {
  if (mState == M_TRAINING) return trainStep(o);
  if (mState == M_SOLVING || mState == M_RETURNING) return execStepAction(o);
  return 'X';
}

char missionOnDeadEnd(const NodeObs& o) {
  if (mState == M_TRAINING) return trainStep(o);
  if (mState == M_SOLVING || mState == M_RETURNING) return execStepAction(o);
  return 'X';
}

char missionOnCircle(const NodeObs& o) {
  if (mState == M_TRAINING) return trainStep(o);
  if (mState == M_SOLVING || mState == M_RETURNING) return execStepAction(o);
  return 'X';
}

void missionOnExitChanged(uint8_t newDir) {
  if (mState == M_TRAINING) {
    expExitChanged(newDir);
  } else if (mState == M_SOLVING || mState == M_RETURNING) {
    if (execExitChanged(newDir) != STEP_GO) {
      sendError("REPLAN_FAIL");
      setMission(M_ERROR);
      sPendingStop = true;          // nav is mid-maneuver: stop on next loop
    }
  }
}

void missionOnTurnCancelled(uint8_t heading) {
  if (mState == M_TRAINING) expHeadingFix(heading);
}

void missionOnNavFailed(const char* reason) {
  snprintf(tx, sizeof(tx), "ERROR:NAV_FAILED,%s", reason);
  linkSend(tx, true);
  if (mState == M_TRAINING && expEndFound()) trainingFinished(true);
  if (running()) setMission(M_ERROR);
}

void missionOnLink(bool connected) {
  if (connected) {
    sendReady();
    sendStatus(true);
  }
}

// ================= commands =================

static bool is(const char* a, const char* b) { return strcmp(a, b) == 0; }

// ---- motor balance tools ----
static unsigned long sDriveTestEnd = 0;     // 0 = no drive test running

static void loadTrims() {
  if (EEPROM.read(EE_TRIM_ADDR) != 'T') return;
  uint8_t l = EEPROM.read(EE_TRIM_ADDR + 1), r = EEPROM.read(EE_TRIM_ADDR + 2);
  if (l >= 50 && l <= 150) gTrimLeftPct = l;
  if (r >= 50 && r <= 150) gTrimRightPct = r;
}

static void saveTrims() {
  EEPROM.update(EE_TRIM_ADDR, 'T');
  EEPROM.update(EE_TRIM_ADDR + 1, gTrimLeftPct);
  EEPROM.update(EE_TRIM_ADDR + 2, gTrimRightPct);
}

static void sendTrims() {
  snprintf(tx, sizeof(tx), "TRIM:L=%u,R=%u", gTrimLeftPct, gTrimRightPct);
  linkSend(tx, true);
}

// "TRIM_L:110" -> value 110 (accepted range 50..150 %)
static bool parseTrim(const char* cmd, const char* prefix, uint8_t* out) {
  size_t n = strlen(prefix);
  if (strncmp(cmd, prefix, n) != 0) return false;
  int v = atoi(cmd + n);
  if (v < 50 || v > 150) return false;
  *out = (uint8_t)v;
  return true;
}

static void beginTraining() {
  sDriveTestEnd = 0;
  storageAbort();
  expBegin(0, 0, START_HEADING);
  sPathValid = false;
  if (sAtStartFacingIn) odoReset(0, 0, dirBack(START_HEADING));
  else odoReset(0, 0, START_HEADING);
  navStart(sAtStartFacingIn, false);
  sAtStartFacingIn = false;
  sTrainStart = millis();
  storageSetRunFlag(true);
  setMission(M_TRAINING);
  linkSend("TRAINING_STARTED", true);
}

static void beginSolving() {
  sDriveTestEnd = 0;
  execBegin(sPath, sPathLen);
  const MazeNode& s = gMap.node[gMap.startNode];
  uint8_t h = gMap.startHeading;
  if (sAtStartFacingIn) odoReset(s.x, s.y, dirBack(h));
  else odoReset(s.x, s.y, h);
  navStart(sAtStartFacingIn, true);
  sAtStartFacingIn = false;
  storageSetRunFlag(true);
  setMission(M_SOLVING);
  linkSend("SOLVING_STARTED", true);
  startDumps(false, true);
}

void missionCommand(const char* cmd) {
  if (is(cmd, "START_TRAIN") || is(cmd, "TRAIN") || is(cmd, "START") || is(cmd, "GO")) {
    if (running()) { sendError("BUSY"); return; }
    sendAck("START_TRAIN");
    beginTraining();

  } else if (is(cmd, "START_SOLVE") || is(cmd, "SOLVE")) {
    if (running()) { sendError("BUSY"); return; }
    if (!sPathValid) { sendError("NO_PATH"); return; }
    sendAck("START_SOLVE");
    beginSolving();

  } else if (is(cmd, "STOP")) {
    sDriveTestEnd = 0;
    navStop();
    sendAck("STOP");
    if (running()) setMission(M_STOPPED);

  } else if (is(cmd, "RESET")) {
    // Stops and returns to READY. The map and path are KEPT (use CLEAR_MAP).
    navStop();
    sAtStartFacingIn = false;
    sendAck("RESET");
    setMission(M_READY);
    sendReady();

  } else if (is(cmd, "STATUS_REQUEST") || is(cmd, "STATUS")) {
    sendStatus(true);

  } else if (is(cmd, "GET_MAP") || is(cmd, "MAP")) {
    sendAck("GET_MAP");
    startDumps(true, false);

  } else if (is(cmd, "GET_PATH") || is(cmd, "PATH")) {
    if (!sPathValid) { sendError("NO_PATH"); return; }
    sendAck("GET_PATH");
    startDumps(false, true);

  } else if (is(cmd, "CLEAR_MAP")) {
    if (running()) { sendError("BUSY"); return; }
    mapClear();
    storageErase();
    sPathValid = false;
    sendAck("CLEAR_MAP");

  } else if (is(cmd, "ODO")) {
    snprintf(tx, sizeof(tx), "ODO:dist=%ld,x=%ld,y=%ld,h=%c,rot90=%ld",
             (long)odoDistance(), (long)gPose.x, (long)gPose.y,
             DIR_CHARS[gPose.heading], (long)odoRotPer90());
    linkSend(tx, true);

  } else if (strncmp(cmd, "TRIM_L:", 7) == 0 || strncmp(cmd, "TRIM_R:", 7) == 0) {
    if (running()) { sendError("BUSY"); return; }
    uint8_t v;
    if (parseTrim(cmd, "TRIM_L:", &v)) gTrimLeftPct = v;
    else if (parseTrim(cmd, "TRIM_R:", &v)) gTrimRightPct = v;
    else { sendError("BAD_TRIM,USE_50_TO_150"); return; }
    saveTrims();
    sendTrims();

  } else if (is(cmd, "TRIM")) {
    sendTrims();

  } else if (is(cmd, "DRIVE_TEST") || strncmp(cmd, "DRIVE_TEST:", 11) == 0) {
    // Open loop, both sides at SPEED_BASE. Put the robot on plain floor
    // (no line needed). Optional duration: DRIVE_TEST:3000 (ms).
    if (running()) { sendError("BUSY"); return; }
    unsigned long ms = DRIVE_TEST_MS;
    if (cmd[10] == ':') {
      long v = atol(cmd + 11);
      if (v < 300 || v > (long)DRIVE_TEST_MAX_MS) { sendError("BAD_DRIVE_TEST,USE_300_TO_10000_MS"); return; }
      ms = (unsigned long)v;
    }
    sendAck("DRIVE_TEST");
    odoReset(0, 0, START_HEADING);            // count distance from zero
    sDriveTestEnd = millis() + ms;
    if (sDriveTestEnd == 0) sDriveTestEnd = 1;
    setSpeeds(SPEED_BASE, SPEED_BASE);

  } else if (is(cmd, "PING")) {
    linkSend("PONG", true);

  } else {
    snprintf(tx, sizeof(tx), "ERROR:BAD_CMD,%s", cmd);
    linkSend(tx, true);
  }
}

// ================= public =================

MissionState missionState()     { return mState; }
bool         missionPathValid() { return sPathValid; }

void missionInit(bool resetDuringRun) {
  loadTrims();
  navInit();
  odoReset(0, 0, START_HEADING);

  linkSend("BOOT", true);
  if (resetDuringRun) {
    sendError("RESET_DURING_RUN");      // brownout or crash mid-run: check the battery
    storageSetRunFlag(false);
  }

  if (storageLoadMap() && computePath(false)) {
    snprintf(tx, sizeof(tx), "EVT:MAP_LOADED,%u,%s", gMap.count, sActions);
    linkSend(tx, true);
  } else {
    mapClear();
    sPathValid = false;
  }
  mState = M_READY;
  mStateStart = millis();
  sendReady();
  sendTrims();
}

void missionUpdate() {
  if (sPendingStop) {
    sPendingStop = false;
    navStop();
  }

  if (running()) {
    navUpdate();
    // Nav stopped on its own while the mission thinks it is running
    if (running() && !navActive()) {
      sendError("NAV_STOPPED");
      setMission(M_ERROR);
    }
  }

  unsigned long now = millis();

  // Drive test: integrate odometry while driving, brake and report at the end
  if (sDriveTestEnd != 0) {
    odoUpdate(false);
    if ((long)(now - sDriveTestEnd) >= 0) {
      sDriveTestEnd = 0;
      brakeMotors();                          // brake so the robot does not coast past the count
      snprintf(tx, sizeof(tx), "EVT:DRIVE_TEST_DONE,L=%u,R=%u,dist=%ld",
               gTrimLeftPct, gTrimRightPct, (long)odoDistance());
      linkSend(tx, true);
    }
  }

  unsigned long period = running() ? STATUS_PERIOD_MS : IDLE_STATUS_PERIOD_MS;
  if (now - lastStatusMs >= period) {
    lastStatusMs = now;
    sendStatus(false);
  }
  if (BLE_DIAG && running() && now - lastDiagMs >= DIAG_PERIOD_MS) {
    lastDiagMs = now;
    sendDiag();
  }

  serviceDumps();
}


// #####################################################################
//  MazeRobot.ino
// #####################################################################
// =====================================================================
//  MazeRobot.ino  -  ECNG 4504 Phase 1: maze training + shortest-path solve
//
//  Hardware (unchanged from Phase 0):
//    Arduino Mega 2560, L298N driver, 5 digital IR line sensors,
//    HM-10 BLE module on Serial1 (9600 baud).
//
//  Software layers (see each header for details):
//    ble_link   BLE/USB line protocol, non-blocking TX queue
//    mission    top-level FSM: READY / TRAINING / RETURNING / SOLVING /
//               COMPLETED / STOPPED / ERROR
//    explorer   training: frontier exploration + loop closure -> graph
//    maze_map   graph storage + Dijkstra/BFS shortest path
//    path_exec  solving: executes the stored route node by node
//    nav        Phase 0 motion FSM (follow, junctions, turns, recovery)
//    odometry   pose from heading + integrated PWM (no encoders)
//    motors / sensors   Phase 0 drivers
//    storage    EEPROM map persistence (survives resets)
//
//  Everything is non-blocking: one pass of loop() takes ~1-2 ms.
// =====================================================================

static unsigned long lastSensorPrint = 0;

static void updateLed() {
  MissionState m = missionState();
  unsigned long t = millis();
  bool on;
  switch (m) {
    case M_COMPLETED: on = true; break;                                    // solid: solved
    case M_ERROR:     on = (t / 100) % 2; break;                           // fast blink
    case M_READY:
    case M_STOPPED:   on = missionPathValid() ? ((t / 250) % 4 == 0)       // short flash: path ready
                                              : ((t / 500) % 2); break;    // slow blink: no map
    default:          on = !allSensorsWhite(); break;                      // running: line seen
  }
  digitalWrite(STATUS_LED, on ? HIGH : LOW);
}

void setup() {
  Serial.begin(115200);
  linkInit();
  motorsInit();
  sensorsInit();
  pinMode(STATUS_LED, OUTPUT);
  halt();

  bool resetDuringRun = storageRunFlag();   // read before anything clears it

  for (int k = 0; k < 3; k++) {             // boot blink (robot is idle here)
    digitalWrite(STATUS_LED, HIGH); delay(150);
    digitalWrite(STATUS_LED, LOW);  delay(150);
  }

  missionInit(resetDuringRun);
}

void loop() {
  pollSensors();
  linkService();
  storageService();

  if (SENSOR_TEST_MODE) {
    halt();
    if (millis() - lastSensorPrint >= PRINT_INTERVAL) {
      lastSensorPrint = millis();
      char s[6];
      sensorString(s);
      char buf[32];
      snprintf(buf, sizeof(buf), "SENSORS:%s", s);
      linkSend(buf, false);
    }
    return;
  }

  missionUpdate();
  updateLed();
  delay(1);   // same loop pacing as Phase 0 (debounce counters were tuned with it)
}
